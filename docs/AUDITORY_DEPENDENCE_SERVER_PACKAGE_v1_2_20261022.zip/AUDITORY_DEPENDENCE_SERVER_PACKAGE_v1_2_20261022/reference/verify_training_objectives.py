"""Torch/NumPy parity and gradient checks for the matched loss references.

If Torch is absent, this script explicitly reports SKIPPED and zero Torch
checks. A zero process exit after a skip does not mean those checks passed.
"""
from __future__ import annotations

import json
import math

import numpy as np


def _expect_error(fn) -> None:
    try:
        fn()
    except ValueError:
        return
    raise AssertionError("Expected ValueError")


def _logsumexp(a: np.ndarray, axis: int) -> np.ndarray:
    maximum = np.max(a, axis=axis, keepdims=True)
    return np.squeeze(maximum + np.log(np.exp(a - maximum).sum(axis=axis, keepdims=True)), axis=axis)


def verify() -> dict:
    try:
        import torch
        from torch.nn import functional as F
    except ImportError as exc:
        return {
            "status": "skipped",
            "reason": "torch_not_installed",
            "detail": str(exc),
            "torch_checks_run": 0,
            "torch_checks_passed": 0,
            "required_server_action": "Run again in the server Torch environment before training",
        }
    from dependence_measure import gaussian_gram, measure_from_grams, parzen_cs
    from training_objectives_torch import (
        centered_cs, raw_cs, sigmoid_pair_loss, symmetric_info_nce,
    )

    rng = np.random.default_rng(20261022)
    n = 8
    base = rng.normal(size=(n, 32))
    audio = base + .25 * rng.normal(size=base.shape)
    u_np = base / np.linalg.norm(base, axis=1, keepdims=True)
    y_np = audio / np.linalg.norm(audio, axis=1, keepdims=True)
    p_np = np.stack([np.roll(np.arange(n), j) for j in range(1, 5)])
    p = torch.tensor(p_np, dtype=torch.int64)
    u = torch.tensor(u_np, dtype=torch.float64, requires_grad=True)
    y = torch.tensor(y_np, dtype=torch.float64)
    su, sy = 1.0, 0.8
    k, l = gaussian_gram(u_np, su), gaussian_gram(y_np, sy)
    expected_raw = parzen_cs(k, l)["raw_cs_nats"]
    expected_excess = measure_from_grams(
        k, l, p_np, null_design="synthetic_training_objective_parity"
    )["excess_cs_nats"]

    passed = []
    loss_raw, stats_raw = raw_cs(u, y, sigma_u=su, sigma_y=sy)
    np.testing.assert_allclose(float(loss_raw.detach()), -expected_raw, atol=1e-12, rtol=0)
    passed.append("raw_cs_numpy_parity")

    loss_centered, stats_centered = centered_cs(
        u, y, sigma_u=su, sigma_y=sy, permutations=p
    )
    np.testing.assert_allclose(float(loss_centered.detach()), -expected_excess, atol=1e-12, rtol=0)
    passed.append("centered_cs_numpy_parity")

    raw_score = -loss_raw
    wrong_scores = torch.stack([
        -raw_cs(u, y[indices], sigma_u=su, sigma_y=sy)[0] for indices in p
    ])
    explicit_loss = -(raw_score - wrong_scores.mean())
    np.testing.assert_allclose(
        float(loss_centered.detach()), float(explicit_loss.detach()), atol=1e-12, rtol=0
    )
    grad_centered = torch.autograd.grad(loss_centered, u, retain_graph=True)[0]
    grad_explicit = torch.autograd.grad(explicit_loss, u, retain_graph=True)[0]
    grad_raw = torch.autograd.grad(loss_raw, u, retain_graph=True)[0]
    torch.testing.assert_close(grad_centered, grad_explicit, atol=1e-11, rtol=1e-10)
    assert float((grad_centered - grad_raw).abs().max()) > 1e-10
    assert stats_centered["null_stop_gradient"] is False
    passed.append("both_real_and_permuted_terms_retain_gradients")

    # Compare an actual normalized-output parameter path, not only free u rows.
    w = torch.tensor(base, dtype=torch.float64, requires_grad=True)
    normalized = F.normalize(w, dim=1)
    objective = centered_cs(
        normalized, y, sigma_u=su, sigma_y=sy, permutations=p
    )[0]
    grad_w = torch.autograd.grad(objective, w)[0]
    h = 1e-5
    values = []
    for sign in (-1.0, 1.0):
        altered = w.detach().clone()
        altered[0, 0] += sign * h
        values.append(float(centered_cs(
            F.normalize(altered, dim=1), y,
            sigma_u=su, sigma_y=sy, permutations=p
        )[0]))
    numeric = (values[1] - values[0]) / (2*h)
    np.testing.assert_allclose(float(grad_w[0, 0]), numeric, atol=2e-9, rtol=2e-5)
    assert bool(torch.isfinite(grad_w).all())
    passed.append("centered_cs_normalized_path_finite_difference")

    collapsed = torch.zeros((n, 32), dtype=torch.float64)
    collapsed[:, 0] = 1.
    collapsed.requires_grad_(True)
    c_loss, _ = centered_cs(
        collapsed, y, sigma_u=su, sigma_y=sy, permutations=p
    )
    c_grad = torch.autograd.grad(c_loss, collapsed)[0]
    np.testing.assert_allclose(float(c_loss.detach()), 0., atol=1e-12, rtol=0)
    assert float(c_grad.abs().max()) < 1e-12
    passed.append("constant_embedding_centered_score_and_gradient_zero")

    separated = torch.eye(32, dtype=torch.float64)[:n].clone().requires_grad_(True)
    identity_loss, identity_stats = centered_cs(
        separated, y, sigma_u=1e-3, sigma_y=sy, permutations=p
    )
    np.testing.assert_allclose(float(identity_loss.detach()), 0., atol=1e-12, rtol=0)
    np.testing.assert_allclose(
        identity_stats["raw_cs_nats"], -math.log(float(l.mean())), atol=1e-12, rtol=0
    )
    passed.append("identity_kernel_pairing_invariant_reward_cancels")

    temp = .07
    logits = u_np @ y_np.T / temp
    expected_nce = .5 * (
        np.mean(_logsumexp(logits, 1) - np.diag(logits))
        + np.mean(_logsumexp(logits, 0) - np.diag(logits))
    )
    nce, _ = symmetric_info_nce(u, y, temperature=temp)
    np.testing.assert_allclose(float(nce.detach()), expected_nce, atol=1e-12, rtol=1e-12)
    nce_grad = torch.autograd.grad(nce, u, retain_graph=True)[0]
    assert bool(torch.isfinite(nce_grad).all()) and float(nce_grad.abs().max()) > 0
    passed.append("symmetric_info_nce_numpy_parity_and_gradient")

    bias = -math.log(n-1)
    shifted = logits + bias
    expected_sigmoid = float((np.logaddexp(0., shifted).sum() - np.trace(shifted)) / n)
    sigmoid, sigmoid_stats = sigmoid_pair_loss(u, y, temperature=temp)
    np.testing.assert_allclose(
        float(sigmoid.detach()), expected_sigmoid, atol=1e-12, rtol=1e-12
    )
    np.testing.assert_allclose(sigmoid_stats["bias"], bias, atol=0, rtol=0)
    sigmoid_grad = torch.autograd.grad(sigmoid, u, retain_graph=True)[0]
    assert bool(torch.isfinite(sigmoid_grad).all()) and float(sigmoid_grad.abs().max()) > 0
    passed.append("sigmoid_all_pairs_over_n_bias_parity_and_gradient")

    _expect_error(lambda: raw_cs(u[:3], y[:3], sigma_u=su, sigma_y=sy))
    _expect_error(lambda: raw_cs(u[:, :31], y[:, :31], sigma_u=su, sigma_y=sy))
    _expect_error(lambda: raw_cs(2*u, y, sigma_u=su, sigma_y=sy))
    _expect_error(lambda: raw_cs(
        u, y.clone().requires_grad_(True), sigma_u=su, sigma_y=sy
    ))
    _expect_error(lambda: raw_cs(
        u, y, sigma_u=torch.tensor(1., requires_grad=True), sigma_y=sy
    ))
    _expect_error(lambda: centered_cs(
        u, y, sigma_u=su, sigma_y=sy, permutations=p[:3]
    ))
    identity_bank = p.clone()
    identity_bank[0] = torch.arange(n)
    _expect_error(lambda: centered_cs(
        u, y, sigma_u=su, sigma_y=sy, permutations=identity_bank
    ))
    partial_bank = p.clone()
    partial_bank[0] = torch.tensor([1, 0, 2, 3, 4, 5, 6, 7])
    _expect_error(lambda: centered_cs(
        u, y, sigma_u=su, sigma_y=sy, permutations=partial_bank
    ))
    _expect_error(lambda: centered_cs(
        u, y, sigma_u=su, sigma_y=sy, permutations=p.to(torch.float64)
    ))
    _expect_error(lambda: symmetric_info_nce(u, y, temperature=0))
    passed.append("normalization_dimensions_audio_fixed_sigma_and_null_contracts")

    # Construct an observed wrong pairing, and explicitly include its correction
    # among the training nulls. Search only a fixed small synthetic set so this
    # remains an algebraic no-clipping check rather than a data experiment.
    signed_found = None
    for shift in range(1, n):
        wrong_u = torch.tensor(np.roll(y_np, shift, axis=0), dtype=torch.float64)
        wrong_loss, wrong_stats = centered_cs(
            wrong_u, y, sigma_u=sy, sigma_y=sy, permutations=p
        )
        if wrong_stats["centered_cs_nats"] < -1e-10:
            assert float(wrong_loss) > 0.
            signed_found = wrong_stats["centered_cs_nats"]
            break
    assert signed_found is not None, "Synthetic bank did not exercise a negative centered value"
    passed.append("negative_centered_values_are_not_clipped")

    return {
        "status": "passed",
        "torch_checks_run": len(passed),
        "torch_checks_passed": len(passed),
        "checks": passed,
        "torch_version": torch.__version__,
        "numpy_version": np.__version__,
        "raw_cs_nats": expected_raw,
        "centered_cs_nats": expected_excess,
        "normalized_path_gradient_autograd": float(grad_w[0, 0]),
        "normalized_path_gradient_finite_difference": numeric,
        "negative_centered_toy_nats": signed_found,
        "scope": "Synthetic algebra, parity and gradients; no real EEG training/performance claim",
    }


if __name__ == "__main__":
    print(json.dumps(verify(), indent=2, ensure_ascii=False, allow_nan=False))

