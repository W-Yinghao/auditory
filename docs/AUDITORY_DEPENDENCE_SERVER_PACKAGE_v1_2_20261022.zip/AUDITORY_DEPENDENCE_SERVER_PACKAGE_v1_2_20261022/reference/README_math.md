# Measurement reference and mathematical contract

This directory contains a NumPy reference for traditional Parzen CS measurement and Torch references for matched-episode training objectives. It is not a production trainer and does not implement variational CS. The preserved estimator uses all self-pairs, uniform empirical weights, the complete A/B/C expression and natural logs.

The research center is **dependence that is measurable, comparable under declared conditions, transferable, and useful for decisions**. Time is one measurement axis; no temporal gate or personal-time theory is imposed by these files.

## 1. Entry points

- **gaussian_gram(rows, sigma)**: continuous Gaussian overlap matrix. The overlap SD is sigma; KDE component SD is sigma / sqrt(2).
- **delta_gram(labels)**: categorical counting-measure overlap.
- **calibrate_overlap_sigma(training_rows, calibration_scope, panel_id, multiplier=1)**: calibration for a single panel; do not concatenate different listeners here.
- **calibrate_grouped_overlap_sigma(person_rows, calibration_scope, panel_id, multiplier=1)**: for multiple listeners, pool only each listener's unordered off-diagonal Euclidean distances and take their lower median. Requires equal fixed anchor counts and dimensions per listener, includes zero distances, and has no fallback for a zero median. Returns person IDs, person/row/pair counts and the fixed bandwidth.
- **parzen_cs(k, l)**: raw score and all three potentials.
- **kernel_diagnostics(gram)**: descriptive constant-kernel and identity-kernel flags.
- **validate_permutations(permutations, n)**: syntactic permutation checks; it cannot establish exchangeability.
- **measure_from_grams(k, l, permutations, null_design, ...)** and **measure_dependence(u, v=None, labels=None, sigma_u, sigma_v=None, permutations, null_design, ...)**: raw score, null mean/SD, signed excess, z/status and diagnostic metadata.
- **leave_one_out_raw_cs(k, l)**: complete raw-statistic deletion sensitivity, preserving the original kernels and recording the change from n to n−1.

All parameters after * in the Python signatures are keyword-only. Feature rows are anchors, not independent people. The target must be either continuous v or categorical labels.

Both calibration functions accept only **source_train**, **source_dev**, **target_train_unlabelled** or **declared_target_support**. The third scope means unsupervised calibration on target-cohort **training people**, with declared access; it does not permit target evaluation people or query/test material. A scope string does not certify provenance: retain the panel membership and split digest. All calibrated values are frozen before query measurement and permutation evaluation.

Verification command from the package root:

    python reference/verify_measurement.py

Example measurement command, once the caller has supplied an NPZ with u, v OR labels, and legal permutation indices:

    python reference/dependence_measure.py --input panel.npz --output panel.json --sigma-u 1.0 --sigma-v 1.0 --null-design REGISTERED_NULL_DESIGN

For categorical labels, omit --sigma-v. Add --raw-loo only when the declared raw deletion analysis is needed. This command generates no permutations and estimates no bandwidth from the input panel.

Dependencies: Python 3.10+ and NumPy. Torch is optional for one gradient check; its absence is explicitly reported, not counted as a passed check.

## 2. Complete estimator

With uniform weights:

$$
A=n^{-2}\sum_{ij}K_{ij}L_{ij},\qquad
B=(n^{-2}\sum_{ij}K_{ij})(n^{-2}\sum_{ij}L_{ij}),
$$

$$
C=n^{-3}\sum_i\left(\sum_jK_{ij}\right)\left(\sum_kL_{ik}\right),\qquad
\widehat D=\log A+\log B-2\log C.
$$

No statistic is clipped to zero. This is a CS divergence estimate, not a Shannon MI estimate. Gaussian/delta kernel functions retain unit self-pairs. Arbitrary caller-supplied matrices should not be substituted merely because they pass symmetry/range checks.

### Saturation is possible in two directions

- If K is all ones (constant EEG), the full score is zero.
- If K=L=I, the score is log n, even though pairing is irrelevant; every permutation gives the same score.
- More generally, if K=I and L has unit diagonal, the score is −log(mean L), again independent of pairing.

Consequently, a rising raw CS score can reflect increasing feature separation and a diagonal-dominated kernel. Log raw score, null mean, excess score, both Gram diagnostics and representation variance; do not treat raw improvement alone as learned dependence.

## 3. The revised collapse claim is still not a theorem

The attachment's new P1 says that collapse is an InfoNCE descent direction under weak/anticorrelated initialization, while CS has its minimum at collapse and therefore avoids it. Only a limited endpoint observation is justified.

For two samples y=±1 and u=a y, an unnormalized dot-product InfoNCE objective is:

$$
L_{\mathrm{NCE}}(a)=\log(1+\exp(-2a)),\qquad L_{\mathrm{NCE}}'(0)=-1.
$$

It can descend from anticorrelation through zero to positive alignment. Passing through zero is not proof that it becomes trapped at collapse. For cosine scores, positive rescaling u→a u does not change the objective at all, so shrinking norms is not a universal descent direction.

For the Gaussian CS example with unit bandwidth:

$$
k=\exp(-2a^2),\quad \ell=\exp(-2),\quad
D(a)=\log\frac{2(1+k\ell)}{(1+k)(1+\ell)},\qquad D'(0)=0.
$$

More generally, when all EEG outputs coincide, the derivative of each Gaussian overlap with respect to the output coordinates is zero. Collapse is a stationary point even though it is a global minimum of the score being maximized. This does not prove CS will collapse in training; it disproves an automatic escape guarantee.

**E0 use:** compare actual trajectories using loss, output variance/rank, kernel saturation, and gradients reaching the projector and encoder. Do not infer collapse from loss approaching log N alone, and do not declare CS collapse-proof from nonnegativity.

## 4. What “comparable” means

The primary comparison should be a paired method difference for the same descriptor, same participants, same anchor panel, same access, same sampling size and the same declared calibration rule. Calibration scalars and standardizers are fitted only on allowed source/development data, declared unlabelled target-cohort training people, or declared target support, with provenance retained; they are frozen for query and all null draws.

For source/train measurement calibration across listeners, use **calibrate_grouped_overlap_sigma**. Select the same fixed number of anchors per person, calculate upper-triangle distances separately within each person, then pool those distances. This gives each person equal pair count and excludes between-person identity offsets. Concatenating feature rows before computing pairwise distances violates this protocol. Target-training calibration must use the same within-person rule and cannot refit on held-out evaluation people. The helper checks row counts and scope names; the server must verify actual cohort membership and anchor selection.

Equal dimension, unit variance or a shared bandwidth rule does not turn different attributes into a common information scale. Population CS is not invariant to arbitrary invertible nonlinear transformations.

A verified counterexample uses piecewise-uniform densities on four unit cells:

$$
P=\begin{pmatrix}.6&.1\\.1&.2\end{pmatrix},
\quad
Q=P_UP_V=\begin{pmatrix}.49&.21\\.21&.09\end{pmatrix}.
$$

CS is 0.1199618131. An invertible piecewise-linear rescaling of the first coordinate with Jacobian 4 in the first interval and 1 in the second changes it to 0.2364293468. Affine standardization of each version to zero mean and unit variance leaves its CS unchanged, so equal variance does not remove the discrepancy.

Therefore:

- Treat attribute profiles as coordinate/protocol-specific measurements.
- Compare methods within an attribute before considering any across-attribute synthesis.
- Do not interpret a target/source ratio as a percentage of retained information.
- Treat n/bandwidth/descriptor sensitivity as measurement characterization, not a claim that a universally comparable scale has already been achieved.
- Null z-scores quantify separation relative to a chosen null variability; they are not universal biological units.

## 5. H11 does not automatically remove SNR

Within-listener correlations across attributes remove a pure constant listener intercept, but do not remove attribute difficulty, descriptor reliability, or shared estimation noise.

For example, if D_sv=a_s b_v and G_sv=c_s b_v, every listener has cross-attribute Spearman correlation 1 whenever a_s,c_s>0, solely because both quantities share the attribute factor b_v. A “transfer law” has not been identified.

For an actionable test:

1. Measure the profile on declared support/development material.
2. Learn the mapping or selection rule on development participants/conditions.
3. Evaluate the selected readout or policy on separate query material and held-out participants/conditions appropriate to the intended generalization.
4. Compare with a fixed development-selected policy and simple signal-quality/descriptor baselines using the same target-data allowance.

Use the same CS measurement for all competing independent EEG encoders. Attention labels and current stimulus identities have different access meanings; document exactly which target information each profile uses. Do not call a profile zero-label if it requires the answer being predicted.

## 6. Residuals and conditional interpretation

A nonlinear residual predictor does not in general solve the conditional-independence problem. If U,W are independent uniform ±1 variables and V=WU, the correct conditional mean E[V|W] is zero. U and the residual V are unconditionally independent, while given W they determine each other.

Keep “residual target dependence relative to predictor g” as the name. If conditional CS is later introduced, define the precise conditional distributions, estimator, support assumptions and null before using its interpretation. It is not a drop-in name change for the existing statistic.

## 7. Null contracts

The code receives explicit permutation indices. Valid indices are necessary but do not prove that a null is scientifically valid.

- Continuous speech: register the valid session/content blocks, excluded temporal offsets, actual encoder/preprocessing support and handling of repeated content. A circular shift is a valid randomization only under its stated exchangeability/stationarity assumptions.
- Oddball: “blockwise label permutation preserving sequence statistics” is not a complete algorithm. Specify which current-label/history relation is broken and which histories, blocks and nuisance variables are preserved. If no valid alternative pairing exists in a stratum, record that limitation; do not manufacture a conditional test.
- Same-stimulus different-listener EEG measures sharedness and should not universally become zero.
- Noise EEG is an input-sensitivity intervention, often out of distribution.
- Neural-source interpretation needs the appropriate device/phantom/artifact controls separately.

Use the same eligible anchors and null index draws for paired method contrasts wherever possible. Repeated windows and overlapping tokens do not increase the number of independent listeners.

A **support-only sparse U10** permutation score is a correspondence-reference score on the selected support anchors. It is not a full-sequence circular shift and has no exact-null permutation p-value claim. Its index maps and labels must come only from the selected, permitted support material; it cannot consume unselected labels or query labels. Record the explicit support-index design and evaluate any profile-based decision against independent query outcomes.

The module reports z=None with a status when null SD is absent or numerically near zero. It retains raw/null/excess values. It does not divide by an epsilon to manufacture a large z and does not output inferential p-values without a validated design.

## 8. Leave-one-out interpretation

This reference removes one paired anchor from the full A/B/C statistic, leaving n−1 rows. It does not refit bandwidth or feature scaling.

For K=L=I, every deletion gives:

$$
D_n-D_{n-1}=\log n-\log(n-1)>0.
$$

All anchors then have the same positive raw deletion change despite pairing-independent dependence. This is a sample-count effect, not useful event-specific information.

The output therefore labels the result **raw full-statistic deletion sensitivity**, includes n_before/n_after, and also provides a mean-centered within-panel value. It is neither an excess contribution nor a significance test.

To define excess-score influence, both the observed and null statistics must be recomputed under an explicitly valid reduced-panel design. Reusing a permutation after deleting a row can remove a different target row from the surrogate and alter marginals; do not silently assume it is the same test.

## 9. Meaningful verification scope

The bundled NumPy suite has 18 checks covering complete A/B/C algebra, constant EEG and constant labels, identity-kernel log n, saturation diagnostics, calibration scope, grouped calibration excluding between-person offsets with equal anchor counts, explicit permutation validation, near-zero z behavior, raw deletion sample-count effects, and independent counterexamples. The Torch check is reported separately and is not included in that count.

These checks do not validate real EEG exchangeability, fit a model, establish CS superiority, validate a clinical association, or demonstrate transfer. Those are the experimental questions the server run must answer.


## 10. Optional permutation-centered CS training objective

The new Torch reference defines:

$$
L_{\mathrm{centered}}
=
-\left[
D_{\mathrm{CS}}(K,L)
-\frac1B\sum_{b=1}^{B}
D_{\mathrm{CS}}(K,P_b L P_b^\top)
\right].
$$

This is a declared training contrast formed from traditional Parzen CS scores. It is **not a new divergence**, unbiased MI estimator, kernel-centering operation or collapse guarantee. The signed contrast is not clipped.

### Why it is a reasonable next candidate

It addresses a specific mechanism: raw paired and mismatched scores may rise together when the representation changes marginal geometry instead of learning correspondence. In the K=I and K=1 limits, the paired and permuted values are identical, so this contrast is zero. Both sides are differentiated with respect to the same EEG Gram; subtracting a detached null would leave the raw-CS gradient unchanged and would not implement this objective.

It remains possible for the contrast to have stationary points, finite-bank variance, poor optimization or other unwanted solutions. Removing one pairing-independent reward does not prove useful learning or transfer. The raw-CS mechanism control should use the same seed, exposure and interface; a single-seed raw control cannot establish cross-seed superiority of centered over raw CS.

### Fixed episode interface

All four references use:

- One listener episode, n>=4.
- The same paired EEG/audio rows.
- Already L2-normalized 32-D outputs.
- Fixed audio rows with no gradient.
- All off-diagonal pairs eligible under the caller's sampler.
- No loss-specific masking, learned scale or hidden feature normalization.

Normalize in float32 or higher before passing rows. A zero audio vector is not silently repaired or dropped; define eligible rows consistently in the sampler.

CS uses fixed calibrated Gaussian overlap sigmas and float64 log-sum-exp algebra, retaining all diagonal terms. InfoNCE is symmetric cosine cross entropy at default temperature 0.07. The sigmoid reference sums all n² logistic terms and divides by n, with default fixed bias −log(n−1) and temperature 0.07. Its original-implementation equivalence is not claimed beyond this declared formula.

### Permutation contract

The training function receives at least four explicit legal permutations. Identity permutations are rejected. The default also requires **derangements**, so no anchor retains its actual match. Excluding only a whole identity permutation would still permit most rows to keep their true pairing.

Permutations reorder both rows and columns of the SAME L; K, U and the forward-pass randomness are shared between paired and wrong terms. All terms retain the gradient to U. There is no stop-gradient on the wrong-pair statistic.

The training sampler owns content/temporal eligibility. Restricted mismatch sampling defines a relative correspondence contrast; it must not automatically be described as exact sampling from the population marginal product.

A small fixed bank can be adapted to during training. Use the registered training seed stream to draw eligible mappings as episodes change, retain their provenance, and use a separate predeclared evaluation null bank. Avoid choosing permutation counts or banks by target-query performance. Record the number of unique maps and fixed-pair fraction. Duplicate Monte Carlo draws are reported rather than silently replaced.

The additional reductions cost approximately B+1 CS evaluations, while the two Gram matrices can be reused. Record optimizer exposure and wall time; equal wall time and equal encoder updates are different comparisons.

### API and verification

The training module is **training_objectives_torch.py**. Every public objective returns (loss, detached_stats):

- **raw_cs(u, y, sigma_u, sigma_y, ...)** minimizes negative raw CS.
- **centered_cs(u, y, sigma_u, sigma_y, permutations, ...)** minimizes negative paired-minus-permuted CS.
- **symmetric_info_nce(u, y, temperature=0.07, ...)** uses both retrieval directions.
- **sigmoid_pair_loss(u, y, temperature=0.07, bias=None, ...)** uses the declared all-pair normalization.

Arguments after * in their actual signatures are keyword-only.

Run:

    python reference/verify_training_objectives.py

The verification compares Torch values with the NumPy measurement reference, checks both CS gradient terms, tests an upstream normalized-output finite-difference path, checks constant/identity-kernel limits, and verifies both contrastive losses and input contracts. If Torch is unavailable, it reports **skipped with zero Torch checks run**. That output must not be summarized as a successful gradient/parity test.


