"""Executable algebra/contract checks. No real EEG data and no training."""
from __future__ import annotations

import json
import math

import numpy as np

from dependence_measure import (
    calibrate_grouped_overlap_sigma, calibrate_overlap_sigma, delta_gram,
    gaussian_gram, kernel_diagnostics, leave_one_out_raw_cs, measure_dependence,
    measure_from_grams, parzen_cs, validate_permutations,
)


def _expect_error(fn) -> None:
    try:
        fn()
    except ValueError:
        return
    raise AssertionError("Expected ValueError")


def verify() -> dict:
    passed = []
    for n in (2, 32, 128):
        value = parzen_cs(np.eye(n), np.eye(n))["raw_cs_nats"]
        np.testing.assert_allclose(value, math.log(n), atol=1e-12, rtol=0)
    passed.append("identity_grams_equal_log_n")

    x = np.array([[0.], [1.], [3.], [4.]])
    k = gaussian_gram(x, 1.0)
    np.testing.assert_allclose(k[0, 1], np.exp(-0.5), atol=1e-15, rtol=0)
    np.testing.assert_allclose(np.diag(k), 1.0, atol=0, rtol=0)
    passed.append("gaussian_overlap_kernel_and_self_pairs")

    value = parzen_cs(np.ones((4, 4)), k)["raw_cs_nats"]
    np.testing.assert_allclose(value, 0.0, atol=1e-12, rtol=0)
    passed.append("constant_eeg_full_cs_zero")

    value = parzen_cs(k, delta_gram(np.zeros(4, dtype=int)))["raw_cs_nats"]
    np.testing.assert_allclose(value, 0.0, atol=1e-12, rtol=0)
    passed.append("constant_category_full_cs_zero")

    y = np.array([0, 0, 0, 1])
    np.testing.assert_array_equal(delta_gram(y).sum(axis=1), [3., 3., 3., 1.])
    np.testing.assert_allclose(
        parzen_cs(np.ones((4, 4)), delta_gram(y))["raw_cs_nats"], 0., atol=1e-12
    )
    passed.append("gram_row_sums_are_not_full_cs_contributions")

    n = 8
    # These cyclic maps are solely toy algebra inputs, NOT a default EEG null.
    toy_perms = np.stack([np.roll(np.arange(n), j) for j in range(1, n)])
    m = measure_from_grams(
        np.eye(n), np.eye(n), toy_perms, null_design="synthetic_identity_gram_test"
    )
    np.testing.assert_allclose(m["excess_cs_nats"], 0.0, atol=1e-12, rtol=0)
    assert m["z"] is None and m["z_status"] == "near_zero_null_sd"
    assert m["k_diagnostics"]["identity_like"]
    passed.append("near_zero_null_sd_z_is_none")

    one = measure_from_grams(
        np.eye(n), np.eye(n), toy_perms[:1], null_design="synthetic_one_draw_test"
    )
    assert one["null_sd_nats"] is None and one["z"] is None
    assert one["z_status"] == "insufficient_null_replicates"
    passed.append("one_null_draw_has_no_sd_or_z")

    loo = leave_one_out_raw_cs(np.eye(n), np.eye(n))
    np.testing.assert_allclose(
        loo["raw_deletion_change_nats"], math.log(n) - math.log(n - 1), atol=1e-12
    )
    np.testing.assert_allclose(
        loo["mean_centered_raw_deletion_change_nats"], 0., atol=1e-12
    )
    assert loo["includes_sample_count_effect"] and loo["not_excess_contribution"]
    assert loo["n_before"] == n and loo["n_after"] == n - 1
    passed.append("raw_leave_one_out_records_uniform_sample_count_effect")

    rng = np.random.default_rng(44021)
    u = rng.normal(size=(24, 2))
    v = u + 0.05 * rng.normal(size=u.shape)
    toy_perms = np.stack([np.roll(np.arange(24), j) for j in range(1, 24)])
    result = measure_dependence(
        u, v, sigma_u=1., sigma_v=1., permutations=toy_perms,
        null_design="synthetic_iid_positive_control_only"
    )
    assert result["excess_cs_nats"] > 0
    assert result["z_status"] == "ok"
    assert not result["exchangeability_validated_by_this_module"]
    passed.append("deterministic_paired_toy_has_positive_excess")

    cal = calibrate_overlap_sigma(
        np.array([[0.], [1.], [3.]]), calibration_scope="source_train",
        panel_id="synthetic_training_panel"
    )
    np.testing.assert_allclose(cal["overlap_sigma"], 2., atol=0, rtol=0)
    _expect_error(lambda: calibrate_overlap_sigma(
        x, calibration_scope="test", panel_id="forbidden"
    ))
    _expect_error(lambda: calibrate_overlap_sigma(
        np.zeros((4, 1)), calibration_scope="source_train", panel_id="collapsed"
    ))
    passed.append("calibration_lower_median_scope_and_no_fallback")

    # An arbitrary listener identity offset must not set the within-listener
    # measurement bandwidth. Concatenating rows would fail this contract.
    anchors = np.array([[0.], [1.], [3.]])
    groups = {"person_a": anchors, "person_b": anchors + 1000.}
    grouped = calibrate_grouped_overlap_sigma(
        groups, calibration_scope="source_train", panel_id="toy_grouped_panel"
    )
    shifted = calibrate_grouped_overlap_sigma(
        {"person_a": anchors, "person_b": anchors + 1_000_000.},
        calibration_scope="source_train", panel_id="toy_shifted_panel"
    )
    incorrect_pooled = calibrate_overlap_sigma(
        np.concatenate(list(groups.values())), calibration_scope="source_train",
        panel_id="toy_intentionally_incorrect_between_person_pool"
    )
    np.testing.assert_allclose(grouped["overlap_sigma"], 2., atol=0, rtol=0)
    np.testing.assert_allclose(shifted["overlap_sigma"], 2., atol=0, rtol=0)
    assert incorrect_pooled["overlap_sigma"] > 900.
    assert grouped["n_people"] == 2 and grouped["n_rows_per_person"] == 3
    assert grouped["n_pairs_per_person"] == 3 and grouped["n_pairs"] == 6
    assert grouped["n_rows_total"] == 6
    assert grouped["person_ids"] == ["person_a", "person_b"]
    assert grouped["equal_person_pair_weight"]
    assert not grouped["cross_person_pairs_included"]
    passed.append("grouped_calibration_excludes_between_person_offsets")

    for invalid_groups in (
        {},
        {"a": anchors, "b": anchors[:2]},
        {"a": anchors, "b": np.repeat(anchors, 2, axis=1)},
        {"a": anchors, "b": np.full((3, 1), np.nan)},
        {"a": np.zeros((3, 1)), "b": np.ones((3, 1))},
        {"": anchors},
    ):
        _expect_error(lambda invalid_groups=invalid_groups:
            calibrate_grouped_overlap_sigma(
                invalid_groups, calibration_scope="source_train",
                panel_id="invalid_grouped_panel"
            )
        )
    passed.append("grouped_calibration_requires_equal_counts_and_dimensions")

    for calibrator, data in (
        (calibrate_overlap_sigma, anchors),
        (calibrate_grouped_overlap_sigma, groups),
    ):
        allowed = calibrator(
            data, calibration_scope="target_train_unlabelled",
            panel_id="target_training_people_only"
        )
        assert allowed["calibration_scope"] == "target_train_unlabelled"
        assert allowed["fixed_after_calibration"]
        for forbidden_scope in ("query", "test", "target_query", "target_test"):
            _expect_error(lambda forbidden_scope=forbidden_scope:
                calibrator(data, calibration_scope=forbidden_scope, panel_id="forbidden")
            )
    passed.append("target_train_unlabelled_scope_allowed_query_test_rejected")

    _expect_error(lambda: validate_permutations(np.array([[0, 0, 2, 3]]), 4))
    _expect_error(lambda: validate_permutations(np.array([[0, 1, 2, 4]]), 4))
    _expect_error(lambda: validate_permutations(np.array([[0., 1., 2., 3.]]), 4))
    _expect_error(lambda: validate_permutations(np.array([[0, 1, 2]]), 4))
    passed.append("malformed_permutations_rejected")

    _expect_error(lambda: gaussian_gram(np.array([[0.], [np.nan]]), 1.))
    _expect_error(lambda: gaussian_gram(x, 0.))
    _expect_error(lambda: parzen_cs(np.eye(3), np.eye(4)))
    _expect_error(lambda: delta_gram(np.array([0., 1.])))
    _expect_error(lambda: measure_dependence(
        x, x, labels=np.zeros(4, dtype=int), sigma_u=1., sigma_v=1.,
        permutations=np.array([[0, 1, 2, 3]]), null_design="invalid_both_targets"
    ))
    passed.append("invalid_shapes_targets_bandwidths_and_nonfinite_rejected")

    diag_i = kernel_diagnostics(np.eye(4))
    diag_c = kernel_diagnostics(np.ones((4, 4)))
    assert diag_i["identity_like"] and not diag_i["constant_like"]
    assert diag_c["constant_like"] and not diag_c["identity_like"]
    passed.append("distinct_identity_and_constant_kernel_diagnostics")

    # Independent finite-difference check of the proposed collapse claim.
    def nce(a):
        return np.logaddexp(0., -2. * a)
    def cs(a):
        off_k, off_l = np.exp(-2. * a * a), np.exp(-2.)
        return np.log(2. * (1. + off_k * off_l) / ((1. + off_k) * (1. + off_l)))
    h = 1e-6
    dnce = float((nce(h) - nce(-h)) / (2. * h))
    dcs = float((cs(h) - cs(-h)) / (2. * h))
    np.testing.assert_allclose(dnce, -1., atol=1e-8, rtol=0)
    np.testing.assert_allclose(dcs, 0., atol=1e-12, rtol=0)
    passed.append("toy_collapse_nce_nonzero_derivative_cs_zero_derivative")

    # A coordinate counterexample; subsequent affine standardization leaves
    # each population CS value unchanged, so unit variance cannot fix it.
    p = np.array([[.6, .1], [.1, .2]])
    q = p.sum(axis=1)[:, None] * p.sum(axis=0)[None, :]
    coordinate_values = []
    for jacobian in (np.array([1., 1.]), np.array([4., 1.])):
        inverse_j = 1. / jacobian[:, None]
        a = np.sum(inverse_j * p * p)
        b = np.sum(inverse_j * q * q)
        c = np.sum(inverse_j * p * q)
        coordinate_values.append(float(np.log(a) + np.log(b) - 2. * np.log(c)))
    np.testing.assert_allclose(
        coordinate_values, [0.11996181310865817, 0.23642934683845063], atol=1e-12
    )
    passed.append("population_cs_not_general_coordinate_invariant")

    optional_torch = {"status": "not_run", "reason": "torch_not_installed"}
    try:
        import torch
    except ImportError:
        pass
    else:
        z = torch.zeros((4, 2), dtype=torch.float64, requires_grad=True)
        target = torch.arange(4, dtype=torch.float64)[:, None]
        kg = torch.exp(-0.5 * (z[:, None, :] - z[None, :, :]).square().sum(-1))
        lg = torch.exp(-0.5 * (target[:, None, :] - target[None, :, :]).square().sum(-1))
        a = (kg * lg).mean()
        b = kg.mean() * lg.mean()
        c = (kg.mean(1) * lg.mean(1)).mean()
        score = a.log() + b.log() - 2. * c.log()
        score.backward()
        maximum = float(z.grad.abs().max())
        assert maximum < 1e-12
        optional_torch = {
            "status": "passed", "check": "constant_embedding_cs_output_gradient",
            "max_abs_gradient": maximum, "torch_version": torch.__version__
        }

    return {
        "status": "passed",
        "n_numpy_checks": len(passed),
        "numpy_checks": passed,
        "numpy_version": np.__version__,
        "collapse_toy": {"nce_derivative_at_zero": dnce, "cs_derivative_at_zero": dcs},
        "coordinate_counterexample_cs": coordinate_values,
        "optional_torch": optional_torch,
        "scope": "Algebra and input contracts only; no real-data validity or performance claim"
    }


if __name__ == "__main__":
    print(json.dumps(verify(), ensure_ascii=False, indent=2, allow_nan=False))

