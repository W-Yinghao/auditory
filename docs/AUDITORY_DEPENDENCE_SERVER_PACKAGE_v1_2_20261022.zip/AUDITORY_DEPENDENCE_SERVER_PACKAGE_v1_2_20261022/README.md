# Auditory 统计依赖研究：下一轮server交接包

**版本：v1.2 · 2026-10-22 · 项目：W-Yinghao/auditory**

## 这轮做什么

研究中心是：声音–EEG依赖的**可测、在明确条件下可比、可迁移，以及测量如何帮助实际使用**。时间组织是测量轴与子问题。

本包已审阅并统一用户v1.1附件中的正文／修订冲突。加入一个有具体诊断动机、但效果尚待检验的训练改动：正确配对CS减同批合法错配CS。它使用传统核CS；不宣称新散度、无偏MI或防塌缩保证。

下一轮的结果链为：

1. 源学习是否改变正确配对所特有的结构；
2. 各编码器接受共同依赖测量，比较同一属性；
3. 在公共注意及私有当前事件任务上检验用途；
4. 私有U10支持上的依赖测量能否帮助选到更合用的表示。

## 交给server怎样开始

把整个zip解压后，将START_HERE_SERVER.md的正文作为server agent启动任务；让它先读docs，而非直接执行inputs中的旧设计。

本包是**含参考实现的可实施交接**，需要server在当前仓库绑定和集成production wrapper。没有假装提供已跑通的真实数据训练器，也没有自动提交或删除脚本。

## 主要文件

| 路径 | 用途 |
| --- | --- |
| START_HERE_SERVER.md | 可直接交给server agent的完整任务 |
| docs/00_RESEARCH_CONTRACT.md | 主线、可改变假设与结论边界 |
| docs/01_EVIDENCE_AND_REUSE.md | 数字、逐seed阳性、负结果、既有资产与固定来源 |
| docs/02_THIS_ROUND.md | 本轮有限实验、预算与决策 |
| docs/03_METHOD_AND_DATA.md | loss、crop、sampler、校准、null、儿童支持与外部比较 |
| docs/04_SERVER_EXECUTION.md | 最新状态核对、集成、Slurm与复用 |
| docs/05_RESULTS_AND_DECISIONS.md | 端点、统计family、回传及科学讨论 |
| docs/06_REVIEW_CHANGES.md | v1.1修订清单与本轮新增方法身份 |
| configs/round.json | 已固定的机器可读研究配置 |
| configs/server_binding.template.json | 待server填写的真实版本／资产／检查身份 |
| scripts/prepare_round.py | 只读intake、结构校验及逻辑计划生成 |
| reference/ | NumPy测量与PyTorch训练目标、验证脚本 |
| evidence/ | 已知文件索引、完整历史结果资源库、来源与验收状态 |
| inputs/ | 未改动的用户v1.1设计原文，仅作来源 |

## 训练范围

主目标CS-pair、InfoNCE、Sigmoid各3个seed；raw-CS和WRONG各1个诊断seed；B0只测量。E0先比较CS／NCE各自的full／LoRA四个2,500步试训，选择共同模式后续跑其中两个。

合计完成11个10,000步模型，另保留两个未选模式短训；总115,000 source updates。没有额外全儿童FT、多backbone重训、全属性×41lag×5区域矩阵。既有MindMix、local、CB与REVE资产优先复用。

## 本地与server验证状态

详见evidence/VALIDATION.json。

- NumPy测量：18项实际核查通过。
- PyTorch loss／梯度：本环境未安装Torch，实际结果为skipped，server须运行验证。
- 配置、逻辑计划、Python语法及未绑定模板拒绝：制包时验证。
- 真实数据、GPU训练、Slurm调度、最新仓库集成：本包制作者未执行。

示例命令（从包根目录；计算型验证在server按项目规则走Slurm）：

    python reference/verify_measurement.py
    python reference/verify_training_objectives.py
    python scripts/prepare_round.py plan --out /your/work/round_plan.json
    python scripts/prepare_round.py intake --repo /your/repo --out /your/work/intake.json --fetch --queue
    python scripts/prepare_round.py validate --binding /your/work/server_binding.json --stage source

路径是用户server工作目录的占位示例，需要替换；逻辑plan不会提交job。模板未填时报invalid是预期行为。

## 当前证据版本与限制

本次实时GitHub网页／API／git访问未成功。包内结果基线为**063bef5d0234c523043d6eef708f8defe2584d88**，必须由server重新核对最新推送、receipt和项目任务，尤其R2与MindMix完整结果；不按旧缺项重复拟合。

旧资源库包含看过结果后的探索和回顾性重算。原文与历史结论不因此变成新确认实验。本轮也不能把反复开发过的公开队列改名为从未使用的测试集。

SHA256SUMS覆盖包内全部文件（不包含其自身）。本包不含数据、模型权重、真实server凭据或自动发布权限。

