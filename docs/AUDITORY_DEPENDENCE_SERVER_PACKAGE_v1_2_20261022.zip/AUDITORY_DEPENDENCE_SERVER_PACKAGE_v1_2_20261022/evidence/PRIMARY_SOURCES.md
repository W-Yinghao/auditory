# 外部原始来源与证据身份

本包只根据已核查原文／本地源码与归档实验设计下一轮。以下为可携带的原始来源，不表示制包时重新连通了所有远端。

- MindMix，ICLR 2026 conference paper；三stage、CALRA、A.5/A.8/A.9按各自协议阅读：
  https://proceedings.iclr.cc/paper_files/paper/2026/file/b0ae046e198a5e43141519868a959c74-Paper-Conference.pdf
- MindMix官方代码，已读源码固定快照：
  https://github.com/CookieMikeLiu/MindMix/tree/98445f368efcb161c638172501bd16f92d09a89d
- Contrastive Predictive Coding／InfoNCE原论文；log N关系是相应MI下界的限制：
  https://arxiv.org/html/1807.03748v2
- Sigmoid Loss for Language Image Pre-Training原论文；本包只比较明示的sigmoid pairwise目标，不声称复现原模型：
  https://arxiv.org/html/2303.15343v2
- Auditory已归档结果快照：
  https://github.com/W-Yinghao/auditory/tree/063bef5d0234c523043d6eef708f8defe2584d88

具体实验数字的固定文件链接见docs/01；完整历史资源库见本目录ARCHIVED_RESULTS_LIBRARY_20261022.md。该资源库中任何“当前”“尚缺”等时间性表述只属于原归档时点，接包状态以server新核查为准。

数学reference的反例与数值检查是本包直接推导和计算；配对参照CS不冒称此前已发表的新散度，也未完成独立的新颖性主张验证。

输入v1.1原文保留于inputs/user_framework_v1_1.md；其原始hash见evidence/PROVENANCE.json。本文档及本包统一执行合同优先于输入中仍残留的前后冲突。

