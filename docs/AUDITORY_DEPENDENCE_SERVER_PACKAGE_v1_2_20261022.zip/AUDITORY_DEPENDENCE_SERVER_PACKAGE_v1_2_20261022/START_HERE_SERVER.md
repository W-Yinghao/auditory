# 发给server agent的启动指令

你正在继续W-Yinghao/auditory，不是重启项目。请完整执行本包这一轮，并把既有结果纳入判断。

## 首要研究约定

主线是：声音–EEG依赖能否可测、在规定条件下可比、可迁移，以及测量怎样帮助实际使用。时间组织是测量轴和子问题。不要恢复三窗gate／个人δ为必做主方法，不要把“信息变化vs时间利用各占多少”写回总问题。

CS是主要发展候选，InfoNCE、Sigmoid和MindMix强比较必须保留。私有儿童承担当前事件／history之外与有限支持表示选择；不是装饰性外测。保留所有有效正负、逐seed阳性和去标识个体结果。

## 先读文件

按00_RESEARCH_CONTRACT → 01_EVIDENCE_AND_REUSE → 02_THIS_ROUND → 03_METHOD_AND_DATA → 04_SERVER_EXECUTION → 05_RESULTS_AND_DECISIONS的顺序读docs。本包inputs原文只作为设计来源；冲突处以本包统一合同和用户最新指示为准。

## 先完成当前状态恢复，再实施

本包制作者未能实时访问GitHub。固定063bef5结果快照不是最新状态。请读取当前AGENTS、git工作树、远端最新提交、receipt和精确项目任务，核对R2及MindMix尾项和全fold结果。已有产物能复用则不重新训练。

在独立版本目录／worktree中集成；不要修改正在运行的脚本。先填server_binding副本，明确所有代码／数据／checkpoint、数据访问与实际null规则，再实施source sampler、trainer和下游adapter。包内reference是数值定义，不是现成production pipeline。

按02固定四短训的E0并选共同模式，再完成9个主模型和2个诊断模型；选中的两个seed3401从2500步续跑。没有阳性准入阈值。数值／映射／泄漏错误修复对应路径，有限弱结果继续并保留。

先完成必做：共同测量、DTU／FAU注意、私有U0／U10使用、完整MindMix外部报告。可选public selector和新三窗输入扰动不阻塞主产物；不自动补新描述子或设备模拟。

## 权限和资源

遵守10 GPU running+pending总帽；计算走Slurm；不用scontrol；不重置holds、不取消不相关任务；原始数据树只读。本包没有删除A3d/A3c/A3b/ALN2资产的授权，没有新增外部发布或发送消息的指令。

## 验证与回传

在server Torch环境运行两个reference验证脚本；当前制包端只完成NumPy，Torch明确未运行。记录真实小batch、完整参数更新、保存恢复、候选对称评分与support/query隔离。

最终回传05要求的完整结果包。每个seed和每个人保留，不能只给平均数或最好seed。必须说清学习、测量、用途及选择各自成立到什么程度，并指出下一轮最少需要什么证据；不要根据单次容易写作的结果改写研究中心。

