# 04 Server接包与执行

## 1. 交付身份

这是供server agent整合当前仓库并执行的一轮研究包，包含可执行的数学reference、配置、只读intake／逻辑计划工具及明确实验合同。它不是已经在真实server集成和验收的production release。

制包时GitHub网页、API、git均未成功连接；本包结果基线是063bef5d0234c523043d6eef708f8defe2584d88，不表示当前最新HEAD。旧checkout的函数已读过，但不能据此宣称较新module已经检查完。

## 2. 开始顺序

1. 读当前仓库AGENTS及其适用范围。用户最新中心和个体去标识输出授权优先于历史论文定位／重复审批条款。
2. 在当前repo执行只读状态核对，并fetch远端引用；不要自动pull、checkout或改变运行中代码。
3. 用scripts/prepare_round.py intake记录当前HEAD、origin HEAD、工作树改动、既有文件、已知结果缺项。可加--fetch；仅fetch引用，不合并。输出放本轮独立work目录。
4. 查询当前用户项目精确任务及receipt，建立完成／运行／待补清单，核查随后推送的结果。旧“29/30”“8/10”只作检索线索。
5. 建立隔离worktree／版本目录，绑定实际代码和资产。不得修改正在运行任务使用的文件或复用旧output目录。
6. 填configs/server_binding.template.json的副本；每个blocked项目写原因和不受影响的可继续项。人工核对内容后运行validate。结构校验不会证明科学数据隔离。
7. 在Slurm完成NumPy／Torch reference、实际小batch、保存续跑与访问审计；生成真实wrapper。不得只把旧env/NCE Stream换loss后宣布人内多视图已实现。
8. 先完成E0，固定共同模式；按选中模式恢复对应两个seed3401 checkpoint，完成生产及共同测量／用途。已就绪的旧结果汇总和外部比较可同时推进。
9. 按05回传全部端点、每个seed及明示未完成项。

不因低效应暂停整个研究，也不因外部某个fold未就绪阻断其他独立工作。明确的数值、映射、泄漏或实现错误只阻断对应依赖。

## 3. 必须由server补齐的生产集成

根据当前repo真实模块决定命名，在binding填写路径／commit／hash。最低职责如下：

| 组件 | 实现责任 |
| --- | --- |
| source sampler | 同听者、完整宽窗guard、三view、64个合法anchor、shared schedule、wrong独立映射 |
| source trainer | full与LoRA真实参数组、四种目标、冻结核、可恢复RNG/optimizer、固定开发probe |
| feature exporter | 同层EEG-only表示、跨montage、模型/输入/anchor缓存身份 |
| measurement adapter | 固定校准、合法permutation生成、n与核诊断、共同面板 |
| public scorer | 双候选对称20s、完整窗口guard后的实际anchor支持（理想152）、CS和线性读出接口、标签访问 |
| private adapter | 当前support_contract与history_interface、单截距公平校准、U10五抽样、固定query |
| aggregation | 逐人/seed、原始/合并效应、同时区间、缺失及外部访问分层 |

不必为了新包重建全部已验证loader、临床表或已有事件审计。允许等价复用，但出具精确版本与数值对照。

## 4. 计算和调度边界

- 全部计算性CPU／GPU任务走Slurm；登录节点只做轻量元数据、状态、编辑与提交。
- 用户所有本项目相关running + pending GPU总数上限10；array并发上限不能替代pending总占用核对。保留正在执行的已有任务额度，分批提交。
- 只管理精确属于本项目的任务；不执行scontrol，不批量取消任务、不重置holds。遇到hold记录具体原因，按现有授权和项目规则处理。
- 原始/projects/EEG-foundation-model/auditory只读。派生文件、模型和代码按既有/projects布局存放，不向raw树写入，也不复制数据到home。
- GPU小时先由E0实际每步耗时估计：本轮剩余updates×对应模式实测时间，并单列提取／读出／null测量；不要在未测时给出虚构GPUh。
- 新source预算以02的115,000 updates为上限。私有全FT、多backbone再训练、41lag×5区域不是本轮授权的自动扩展。数值故障修复保留失败成本，重跑按相同单位登记。
- 参考数学及访问检查是执行质量检查，不设科学阳性准入线。

## 5. 缓存、重复与资产

复用条件至少包含：checkpoint hash、code commit、输入物理支持／预处理、montage、feature层、descriptor版本、split/anchor/query哈希。仅文件名相同或指标接近不算复用证明。

模型权重保存一次，fold／probe通过索引引用；保留必要的step快照与续跑状态，避免每个probe复制主干。预测、支持选择记录、核参数、manifest与receipt优先作为可重算结果的入口。

A3d、A3c、A3b与ALN2 D_FM的旧删除问题不由本包自动处理。容量不证明可删；现有资产若被新测量／旧阳性重现依赖，继续保留。此包不附rm命令、不对server执行删除。

## 6. 故障和研究结果分开

每个逻辑单元状态为planned / reused / running / completed / blocked_technical / not_run_optional。completed可包含有效负结果。不得用“failed”统称效应弱与执行错误。

如当前HEAD存在与本合同冲突的新结果，先将其加入SOURCE_UPDATE并说明影响。可解决的实现选择由server记录后执行；改变研究问题、核心端点、支持标签预算或增开大量训练，应留给下一次研究判断，不能悄悄重写配置。

本包不包含自动push、自动发送消息、删除数据或Slurm提交脚本。server按既有明确授权完成执行和既定回传；不能把“用户让做包”扩成新的外部发布授权。

