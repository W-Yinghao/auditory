# 03 方法、数据与测量接口

本文件给server精确实现边界。生产wrapper尚未在当前server版本集成；不得把包内reference当成已经在真实数据跑通的训练器。先绑定当前接口，再在Slurm完成真实小batch及下述数值核对。

## 1. 初始化、输入和主表示

- 主干：可严格装载、已验证通道与位置映射的CBraMod Stage1。同一个权重hash用于B0和全部新训练臂。不能将此前未通过的MindMix EEG-only资产替代后继续称同一比较。
- 源输入：沿用旧CBAUD的确切64Hz整数窗q+[-26:38]，共64点；名义上约[−0.4,+0.6)秒，实际半开支持[−406.25,+593.75)ms、末样点+578.125ms。先native crop，再按已验证路径重采样到200点。不得改成ceil端点的[-25:39]后仍称完全复用。旧64Hz带限输入不被称为原生200Hz。
- 复用已有有效aligned32宽窗访问规则；必须检查整个窗与滤波支持落在允许数据范围。禁止把只保证38点旧gather合法的检查当作1秒完整guard。
- 私有实际epoch仅[−0.2,+0.6)秒、20×200点、250Hz。使用全部可见0.8秒，重采样后在同一1秒容器的前0.2秒补零。明确它比源少200ms真实前文；不能从邻trial或不可见BDF任意补齐。已有native数据允许新访问需另立版本，不在本轮默认改变。
- 私有先按现有获准预处理处理真实0.8秒，再重采样到160点、完成按训练侧规则的标准化，最后前置40个数值零；不把padding算入标准化拟合或真实时长。guard仅检查真实[−0.2,+0.6)秒及实际filter支持，另存padding mask，不用“源1秒必须全有真实数据”拒绝全部儿童。所有新臂与B0一致。
- Backbone所有层从第1步可训练的模式才称full。复用时显式选full_onestep_v1或等价实现，不用legacy aln3默认progressive／LLRD冒充full。
- LoRA：attention Q/V线性层rank8、alpha16、dropout0；主干其余参数冻结、全部训练视图投影头可训练。当前实现的层映射须逐项登记；不在不匹配模块上静默挂接。
- 源训练头：LayerNorm后的有序通道／时间token按真实布局flatten，每个声学视图一个32维线性投影，再L2 normalize。共同音频头固定、不向音频特征或权重回传。
- **共同测量主表示**：冻结backbone的同一预定层，有序flatten后L2 normalize，所有描述子使用同一个U；不使用候选音频条件化。各臂记录层、通道、token形状。训练专用projector单独诊断。
- Source通道特定flatten head不能直接移植到私有20通道或其他montage。迁移的是backbone；目标读出只在允许训练人／support拟合。MindMix只提取独立EEG分支，完整融合输出另作系统评分。

## 2. Source episode 与声音访问

继续使用已审核的SparrKULee fit/dev/bridge角色与内容划分；先核对当前manifest，不用快照人数重建分割。既有访问受限参与者guard原样保留。

每update平均2个听者episode的loss；每人64 anchors。可用梯度累积，但每步看到的听者和anchor数不能因目标而改变。batch不混合不同听者的Gram。

采样规则：

1. 先按现有fit身份抽听者，再抽其合法声音anchors；各臂按seed共享anchor schedule。
2. 同episode内每对anchors必须不属于同一实际内容的近邻或重复呈现；已知内容时钟下最小间隔为max(2秒,完整EEG／音频有效支持宽度)，未知内容时钟下同family不得作negative。
3. 先在sampler排除不合法pair，再计算完整Gram或all-pairs对比目标。不得对CS Gram事后乘NCE mask；那会改变估计对象。
4. 在打开任何开发效果之前，核对全部fit听者的合法episode覆盖：若每人可形成64行，统一n=64；否则全部臂统一n=32并记录触发人数。不能重复行凑满、跨人混合或仅对某目标放宽。连32行都不能形成的身份单列coverage并核查资产／内容映射；不得静默删除或把它算作有效负结果。这是按数据可用性预定的fallback，不是效果调参。
5. 错配为同一episode的无固定点permutation；所有视图同映射。训练每update每人重抽4个，保存RNG身份。合法性来自上述物理内容排除，索引合法本身不证明统计交换性。
6. CS-pair WRONG额外使用独立“正错配”。它与四个reference映射不同；不能构造性相减成零，不能因组合置换意外恢复真配对。回传正错配及参照的实际原anchor映射hash。

训练视图固定env、ss、sc，均为已有rich声音特征：

| 视图 | 已有原始接口 | 约束 |
| --- | --- | --- |
| env | 64Hz归一化包络8点 | 125ms目标支持 |
| ss | 8帧×4维source-fit谱PCA | 展平32维；PCA只来自source-fit |
| sc | 8帧谱变化范数 | 与同一声音anchor对齐 |

声音标准化和固定32维heads复用现有训练侧参数，登记hash与实际时间支持。NCE、Sigmoid、CS收到同样三个视图，每视图权重1/3。未ready的设备或语言视图不进入训练。

## 3. 目标与优化

数学定义与API见reference/README_math.md、training_objectives_torch.py：

- raw-CS为完整Parzen A/B/C、全self-pairs、自然对数、Gaussian overlap核。
- CS-pair为raw真配对减4个合法错配raw均值；两项都求梯度。
- NCE为双向cosine cross-entropy的平均，固定温度0.07。
- Sigmoid为所有n²匹配／不匹配logistic项求和除以n，固定温度0.07、bias=−log(n−1)。它是明确注册的SigLIP-style目标，不声称已复现SigLIP所有优化设置。
- 三视图再平均，两听者再平均。记录各目标的数值尺度、梯度范数与时间；相同update／数据暴露不等于相同FLOPs。

统一AdamW，backbone／LoRA与projection学习率均3e−4，weight_decay1e−4；总10,000 updates的cosine schedule，前500步线性warmup，global grad clip1。所有seed从同一Stage1起点，不warmstart前一目标。若现有full模块不能遵守这一配方，先修wrapper，不能默用旧默认。

CS训练带宽只在更新前的source-fit校准panel拟合：每view U和固定Y的同听者非对角Euclidean距离median作为overlap sigma，跨人汇总这些距离；该view的三种CS臂复用数值，整个生产冻结。乘子1。不得在每batch或target query重估。sigma<=0、非有限值视为技术错误；不靠极小epsilon造带宽。

保存step0、500、2500、5000、10000的引用及完整可续训练状态（optimizer/scheduler/RNG/数据流状态）；E0续跑要验证与未中断日程相同。最主要transfer checkpoint固定10000，不从target query选择最佳快照。低分不是提前停机条件。

## 4. 共同测量与零参照

### 4.1 核和校准

对独立EEG表示U与连续描述子Y使用Gaussian overlap核；current-label用δ核。年龄、听力组与设备时长不在人内生成核。

每个外层fold／队列／模型的EEG带宽，只从该fold允许训练人的固定无标签校准panel估计；每个描述子带宽按同一训练panel规则估计并供所有方法复用。σ和descriptor标准化在query及其全部null draw中固定。主要共同测量允许目标队列训练人的无标签校准，必须在access表披露；另用source-onlyσ的结果只能单列，不与主协议混名。

训练人校准采用同听者非对角距离、各人等量anchor后汇总的lower median，使用reference的grouped校准接口，不把跨人身份距离混入。若训练后表示严格恒定，记录constant_representation并直接用全1 EEG Gram报告raw/null/excess均为0（z不可用），这是该表示的有效结果。若median为0但表示并非全同，记录calibration_degenerate及原始距离，主核测量在此规则下不可估；其他独立读出仍继续。不得把这种学习结果都当软件bug，或用极小epsilon制造核分离。

这种规则给出可复现的协议内比较，不能把所有模型或属性变成相同信息单位。主比较固定同一属性、同一个人、同一anchor与n。冻结backbone不等于没有target校准数据。

### 4.2 面板与重复

主profile每个人每条件固定n=128 anchors的panel，由可定位到物理时钟的规则间隔连续子块组成；不够128时保留实际共同n及coverage，不以重复行补齐。各方法共享完整anchor列表，不能按模型挑高分片段。固定panel抽样seed，保存事件／内容／时钟身份与hash。每个null映射在同一个子块内按真实时钟构造，并验证移位后的描述子确实属于该panel的合法行；不能对跨块／不规则128行直接roll后声称保留真实时间结构。若无法形成此种panel，保留描述性配对参照并明确该限制，不伪称精确随机化。

测量null每panel固定199个候选映射；没有足够不同合法映射则记录实际数量、重复和限制。无需为了凑199重复同一映射。保存null全部数值，不把它们当独立听者。

只在DTU-env和private-δ、seed3401做小面板敏感性：n32/64/128在乘子1下；乘子0.5/1/2在n128下。取嵌套anchor panel，相同n128/乘子1只算一次，不展开3×3。结果用于界定测量稳定性，不能按此再挑最阳性主参数。

### 4.3 连续语音的配对参照

在同一合法录音／内容块内，以完整声音描述子序列作循环移位；禁止独立打乱每个时间点。移位距离至少max(2秒,完整信号支持宽度)，避开同一内容邻近片段及重复呈现，并记录wrap与实际音频边界。source-fit的自相关检查若显示2秒不足，在打开query前提高排除窗、对所有臂使用同一规则。

这是有明确平稳性／可交换性假设的对应关系参照，不是普遍精确null。若session有强非平稳或不足长度，回传描述估计、无法成立的假设及替代错配；不生成伪精确p值。不同录音／说话者的错配单列敏感性，不与主null混成一个均值。

注意用途严格使用20秒query内的真实EEG与候选音频，不越窗读取前后文。125ms hop虽有名义160个anchors，但只保留完整q+[-26:38] EEG窗及音频目标均落在该20秒内的anchors；在64Hz、起点对齐的理想情形为q=32,40,…,1240，共152个，实际以manifest和filter支持记录为准。两个候选共享索引，相关anchors不称独立样本。null只在该query的合法规则间隔panel内移位候选声音，不读取query外的声音。取两候选excess差的符号判定；空支持不可用，平局记0.5。外部比较统一真实20秒访问。不能把只有4个五秒缓存当作已有152个anchor特征。

注意推理不需要p或z；null SD≈0时z不可用但raw/excess依定义保留。不得用query真实注意标签决定bandwidth、shift或margin方向。

这里20秒首先约束编码器直接读取的处理后EEG样本。若缓存采用whole-record离线滤波，其预处理时间混合另行披露并与外部输入对照，不能把它声称为严格在线因果20秒处理；filter有效支持能被核实的边界依原访问合同进一步guard。

### 4.4 儿童当前事件的参照

主要δ测量为表示与当前standard/deviant的边际关系。采用同儿童、同物理block内EEG与完整(label,history)序列的合法相对循环位移；标签和history一起移动，保留序列内部结构，按实际事件窗及历史长度排除邻近位移。不得声称该做法已经条件化history。

对不同协议／SOA分开登记；不跨child60协议混合置换。block太短、过度周期或全同类导致有效置换不足时保留原始描述和原因，z不可用；不为得到p值改成独立label shuffle。技术上不能证明交换性的p值不作确认推断。

主用途的“历史之外”依赖下面的风险差，而非这个δ分数本身。高δ分数可能含history可预测性；selector是否仍有用由独立query检验。

### 4.5 对照与时间轴

不匹配声音对应、同刺激跨人EEG、噪声EEG分别回答配对特异性、共享／个人结构、输入敏感性。跨人同刺激不是独立null；噪声是分布外输入，不单独证明真实模型存在音频捷径。

时间剖面复用已有W0[−200,200)、W1[0,400)、W2[200,600)ms的记录。若新增输入扰动，必须先native crop再resample：64Hz整数窗[-12:13]/[0:26]/[13:39]分别25/26/26点，按既有polyphase规则为200Hz的78/81/81点；私有每窗100点→80点。W2需读取q+38，不能从旧q+[-26:38]源crop内冒充取得。将各crop置于相同1秒零容器的同一固定位置（起点index40），保存真实支持与padding mask，所有臂一致。这是输入支持扰动，不叫瞬时神经响应；既有宽窗内部token也不能冒充原生独立crop。不能先FFT重采样整个宽窗再mask而称为独立crop。

## 5. 私有使用与selector的精确边界

### 5.1 外层折、history与风险

沿用64儿童5外层fold以及现有预处理、block／event guard。q0(h)仅由外层训练儿童的既定pre-QC历史链估计；历史是当前事件之前的previous code/run-length等既有摘要，不含当前标签。

本节source-ES指外层训练儿童中的既定拟合／校准行，不是SparrKULee声音pretraining数据；实际participant/block/event身份必须写入binding。

本轮所需ALN3.5 B1是同source-ES行拟合的history-only单截距：

p_B1 = sigmoid(logit q0(H)+b)；
p_E = sigmoid(logit q0(H)+b_E+w^T U)。

具体PCA、offset logistic、源ES与strict-twin接口复用当前已验证实现；同一组候选用相同复杂度与校准机会。旧auditory_c3/c3dl/hc.py::fit_b1包含EEG evidence，不可作为此处history-only的替代。

主要增量G为同一query上log2 p_E(actual label) − log2 p_B1(actual label)的平均。概率剪裁只用于数值安全，固定[1e−6,1−1e−6]并报告被剪裁比例。G是指定预测器的风险差，不是精确条件MI。

保留真正对应EEG与strict other-block twin，twin为同儿童同history bin、不同物理block、非自身；训练／校准两端不越界。若某条比较只覆盖子集，同时报告该子集与全query的B1差异，不能用子集结果替代全64人总体。

### 5.2 U10预算

复用当前support_contract，不用旧floor(block fraction)函数代替：

n10=min(floor(0.1×全部available trials数), guarded early-support-pool大小)。

early pool来自最早ceil(0.3×物理block数)的pool，经边界trial删除与完整访问guard。U10固定支持抽样seeds351410…351414；不用当前label覆盖抽样。五次支持抽样先在同儿童内平均，人口n仍为儿童数。query对全部方法和支持抽样相同，不随选择结果变动。

标签在选定支持之后可以用于本轮校准与δ评分，因此本任务明确是有标签个人支持。不能将U10改成每类平衡或10%支持池；既有覆盖抽样已显示会改变标签先验。

### 5.3 固定四种策略

每个训练seed内，在外层训练儿童的内层开发独立固定：读出超参、固定最佳表示、并列tie顺序B0→CS-pair→InfoNCE→Sigmoid；不能先挑最好训练seed。每种表示分别在同一训练人／source-ES行拟合自己的PCA与读出，不能共享某个B0的PCA系数来评价旋转后的新表示。目标query完全不参与。

每种候选保留相同source读出。在每次U10上：

1. 用支持数据作相同低维概率校准：logit p_cal=logit p_source+c，最小化mean NLL+0.1c²，惩罚中心为新增c=0；最多100次确定性优化，斜率与encoder不更新。history B1和全部候选用同一support行、同样校准机会。U10 query增量的B1也必须完成同一校准。单类support下正则目标仍可估计；数值失败才保留c=0并报告。
2. 普通读出selector在support内作最多5折的分组交叉验证，验证风险按trial数加权。优先完整物理block；不足2组时，在打开query前将已选support按时间分成连续子块，训练／验证间删除完整EEG与filter有效支持所要求的gap。分组仅使用已选trial时间／block元数据，不用未选当前标签。至少2组且gap后有训练与验证行才能执行；否则固定选择。回传真实CV覆盖及fallback分层，不能把未执行CV的儿童当作战胜强CV基线的证据。
3. CS selector使用同一U10已选行的δ配对参照分数，固定训练人带宽。专用support-only映射：在各block的已选行内按时间排序，枚举无自身对应且实际时距至少max(2秒,完整输入支持)的循环重排，块间组合，最多199个不同映射；不足时保留实际数量。无可用重排的小block保持原位并报告fixed-row比例，至少一个block须有非平凡映射。只读取U10已观察当前标签及获准元数据，绝不能移位完整early pool后读取未选trial标签。它是稀疏支持上的配对参照，不声称保留完整原序列或产生精确随机化p；不因缺少精确检验解释而禁止其query用途测试。若全部block均无非平凡映射、单类或数据太小，则固定选择并说明coverage。raw-minus-reference可计算时不要求z可用。
4. 所有策略最终使用全部U10完成同样单截距校准，在独立共同query输出概率。均匀组合平均四个已校准概率。
5. 输出每次支持的全部四候选分数、选择、fallback、全部query概率与真实标签。每个child×training seed×support seed先单独计算风险／AUC，再在人内平均指标；不能先跨抽样或训练seed平均概率变成未登记ensemble。不要按query再修选择规则。

用于selection的support和query不能共享事件窗口、物理block边界泄漏或同一trial的另一crop。whole-record离线预处理并不自动等于在线因果隔离；实际filter支持列入访问说明。

## 6. 外部MindMix与传统参照

外部路径按当前EXTERNAL_COMPARISON_BINDING定位。保留完整发布系统、既有50epoch目标训练路线、独立EEG分支。若官方原协议与统一候选对称协议不同，二者并列。

同一query两个候选具有同等输入、模型forward、batch背景、温度与聚合机会。禁止先用真实attended声音构造EEG query再只给另一候选不同接口。报告候选交换、EEG错trial／同刺激换人／噪声的敏感性，分别解释；训练16窗口的结果不能替代测试全fold。

Stage1未匹配资产与full融合资产分开；不能为了补checkpoint名称而随机初始化未加载层再称发布模型。严格记录实际装载权重／机械key rename／可训练张量、官方代码commit与实际分支。外部文献和代码索引见evidence/PRIMARY_SOURCES.md。

传统linear envelope readout／TRF使用训练侧拟合，保留已有合格实现。不额外做新网络排行榜；它检验新方法是否超出简单预测关系，和深度模型外部比较承担不同角色。

## 7. 技术验证与执行失败

reference/verify_measurement.py已经在制包环境通过18项NumPy检查。Torch不在本环境，verify_training_objectives.py的实际结果为skipped；不能记作通过。

Server须在Slurm环境跑Torch数值／梯度与真实小batch检查，并验证：

- 新sampler确实人内，所有负配对合法，各臂schedule一致；
- 原始与改写目标数值相符；null项未detach；wrong控制不构造性相消；
- 三声学视图固定、真实full/LoRA参数组、跨montage与保存续跑正确；
- query标签／声音身份／时间访问、支持与query、模型选择边界无泄漏。

明确实现错误阻断受影响路径。弱依赖、低准确率、负效应、统计未分辨是结果，不能作为隐藏失败从交付中删除。

