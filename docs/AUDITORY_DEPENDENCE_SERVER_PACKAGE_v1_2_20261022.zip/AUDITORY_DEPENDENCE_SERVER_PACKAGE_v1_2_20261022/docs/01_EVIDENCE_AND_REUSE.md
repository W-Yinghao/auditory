# 01 已有证据、接包核对与复用边界

## 1. 本文的证据身份

本次 GitHub 网页、API 与 git 连接未成功。以下结果依据此前核查并归档的固定提交：

**063bef5d0234c523043d6eef708f8defe2584d88**

因此，下列“完成／缺项”描述属于该提交，不能直接写成接包时的执行状态。Server 首先核对当前 HEAD、结果清单、生产回执与在跑任务；已有产物能复用时，不因旧公开报告缺项而重复拟合。

本文的职责是记录证据与接口。研究问题、下一轮实验范围、训练配方和统计合同以本包其他正式文档为准。时间结果在这里作为既有资源保存，不自动成为新主线。

指标分别保留：内容相关系数 r、注意准确率、AUC、bit/试次和核 CS 超额依赖不能互相当作同一收益。折、窗口和 seed 不增加独立人数。

## 2. ALN4.1：存在用途不同的积极与消极结果

### 2.1 实际训练身份

R1 五臂是 B0（原 Stage1）、TCS（时间标记 CS）、TNCE（匹配时间结构的 InfoNCE）、GCS（池化后 CS）与 TCS_WRONG。

Stage1 实际使用 **CBraMod**。获得的 MindMix EEG-only 资产当时未通过架构／通道位置映射一致性检查；这轮不能称为完整 MindMix 比较，也不能据此否定另一个 full 融合资产。

SparrKULee 来源训练为81,732段／64人／48个内容 family；开发为6,332段／10人／9 family。R1为seed3401。DTU44人、FAU67人、私有64人及9个family均完整。对应结果不能代替跨seed结论。[E1][E2]

### 2.2 内容、注意与时间结果分别解释

| 对象 | 已归档结果 | 解释 |
| --- | --- | --- |
| FAU 内容，TCS−B0 | Δr +0.01769 [0.00874, 0.02664] | 该冻结内容端点有改善 |
| DTU 内容，TCS−B0 | +0.00288 [−0.00628, 0.01204] | 区间未分辨 |
| DTU／FAU 内容，TCS−TNCE | −0.03379 [−0.04442, −0.02316]／−0.01222 [−0.02176, −0.00269] | TNCE在此内容端点更强 |
| DTU／FAU 内容，TCS−WRONG | +0.03647 [0.02078, 0.05217]／+0.03979 [0.02939, 0.05019] | WRONG本身低于B0，不能全部解释为正确配对带来的净学习收益 |
| DTU 注意20s，TCS−TNCE | +0.02884 [0.00221, 0.05547] | 注意端点的相对优势可与内容端点劣势并存 |
| DTU 注意20s，TCS−B0 | −0.00019 [−0.02445, 0.02407]；两臂约0.626 | 未建立相对原起点的改善 |
| FAU 注意20s | 各臂约0.51–0.53；主要差未分辨 | 保留完整结果，不据此外推整个任务不存在信息 |
| 时间重拟合恢复，TCS−TNCE | DTU +0.02226 [0.00580, 0.03872]；FAU +0.01605 [0.00484, 0.02726] | 更大的恢复可能意味着固定读出更依赖窗口，不能直接称更好时间泛化 |

这些区间为原family同时95%区间；内容端点为冻结 PCA64、q0混合、history残差包络读出的r。注意端点为双候选顺序、20s mean-score，平局记0.5。[E1][E2]

### 2.3 私有儿童与年龄

| 端点 | 已归档结果 | 范围 |
| --- | --- | --- |
| 冻结当前声音 AUC | TNCE0.535、TCS0.525、GCS0.515、WRONG0.512、B0 0.511 | 描述排序不等于history之外的增益 |
| TCS−B0，history条件读出增量 | +0.00164 [−0.00032, 0.00361] bit/试次 | 区间未分辨 |
| 私有CE全参数微调 | B0 0.535、TCS0.537、TNCE0.538 AUC | 已完成固定配方，不因改善小否认已充分执行 |
| TCS−B0／TNCE，微调AUC | +0.00239 [−0.00517,0.00994]／−0.00143 [−0.00926,0.00640] | Stage2额外收益未分辨 |
| 冻结年龄 MAE | B0 25.05月、TCS25.37、TNCE24.90；raw log-variance 32.38，训练均值32.02 | Stage1年龄技能不等于CS Stage2改善 |
| raw−B0／TNCE，年龄MAE改善 | +7.322 [1.369,13.276]／+7.479 [0.340,14.617]月 | 保留技能，不解释为康复或正常成熟度 |
| B0−TCS，年龄MAE改善 | −0.320 [−5.327,4.688]月 | 未建立CS额外年龄收益 |

私有年龄／HA／佩戴时长关联共24个系数，未获族内支持；不能升级为相关信息不存在。[E1][E3]

### 2.4 较早的有效阳性

同access true-full CBpre（InfoNCE，lr3e−4）对local L1的三seed NLL改善：FAU/DTU/Federici为+.141/.213/.180 bit/5s，同时区间均正。[E10]

私有CS的CB预训练full对random full的AUC差：seed3401/3407/3413为+.02234/.01188/.02090，三个同时区间均正；汇总+.01837[.01010,.02665]。这是recipe对比，非CS−InfoNCE；同低LR后初始化增量+.00839[.00169,.01509]。[E11][E12]

## 3. ALN4.2 源学习诊断：要解释的实际现象

这是R1后固定生产checkpoint的分析；比较0／2500／5000／10000更新，零optimizer更新。它不是新的目标搜索，也没有发现需要整轮重跑的错位或梯度缺失bug。[E4]

| 诊断 | 实测 | 含义 |
| --- | --- | --- |
| 投影空间配对检索 | 各臂各快照top-1约0.027–0.035，机会1/32 | 固定面板上未建立正确锚点辨别 |
| TNCE query loss | 4.50→约3.465 nats，接近ln32 | loss下降不等于正确配对已学成 |
| TNCE投影 | 有效秩约18→3.3–3.6，锚点余弦约1 | 该轨迹表现为投影坍缩，不是InfoNCE普遍性质的证明 |
| 正确配对CS诊断 | GCS .011→.020；WRONG .011→.019；TCS .011→.005；TNCE→0 | 该面板变化不具有统一正确配对特异性 |
| Backbone token | 变化相对初态：TNCE约21×、GCS13×、WRONG5.5×、TCS2.9× | 投影坍缩不等于backbone完全没变；下游PCA读出使用backbone token |
| 旧固定ridge探针 | fit NMSE≈0；dev初态1.28、训练后2.0–2.7 | 原高维选模探针过拟合，不能作“EEG没声音信息”的证据 |
| 时间q及支持δ | q约.32–.35；δ norm约1e−4–1e−3；query目标改变量平均绝对值<1e−4 | 没有学到可用时间偏好／该episode支持更新 |
| gate梯度 | 数据梯度通常为KL梯度10–100倍 | “均匀gate由KL压住”没有得到支持 |
| 工程核对 | query梯度、support no_grad、参数组、δ重置、bandwidth均与代码一致 | 有效R1结果保留，不重算为修复一个未发现的bug |

**同时保留两件事：TNCE冻结内容读出较强，投影却没有学会正确配对。** 下一轮要解释具体训练信号与表示用途的关系，不能只按训练loss或最终CS值判定成败。

## 4. 共同CS图谱：已有基础、阳性与逐seed差异

图谱是看过ALN4.1／4.2之后设计的探索性分析。量为真实CS减听者内整段循环移位null均值，以下单位为 **10⁻⁴ nats**；不是Shannon MI、可解码bits或临床效应。[E5]

- ALN4.1：52个冻结单元、23,088个逐人／窗／条件行；TCS/TNCE/GCS/WRONG有3401、3407、3413，B0复用一次。
- ALN3.4：180个单元、123,700行；DTU四模型三seed，FAU/Federici为代表seed3401。
- 相关格子数不能当作独立证据次数。

| 结果 | 数值或范围 |
| --- | --- |
| ALN4.1 DTU包络W0绝对超额依赖 | B0 +1.19 [.86,1.55]；TCS +1.45 [1.09,1.84]；TNCE +1.26 [.82,1.72]；WRONG +.76 [.42,1.07] |
| DTU包络W0方法差 | TCS−WRONG +.69 [.07,1.32]；TCS−GCS +.65 [.03,1.27]；TCS−B0/TNCE未分辨 |
| FAU包络W1 | TNCE−B0 +.69 [.04,1.35]；GCS−B0 +.70 [.16,1.24] |
| 噪声对照示例 | DTU TCS +.06 [−.22,.36]、B0 +.09 [−.18,.35] |
| ALN3.4 local、中心0、包络direct | DTU15.678 [11.734,19.795]；FAU7.628 [5.895,9.619] |

最后一行是learned表示的绝对超额依赖，不能与README的learned−raw差值混用。不同历史接口的幅值也不能直接排序为新旧方法优劣。

### 4.1 被汇总遮住的单seed阳性

FAU env/W1、TCS−B0：

| Seed | 效应及同时95%区间 |
| --- | --- |
| 3401 | +.7330 [.0437,1.4223] |
| 3407 | −.2343 [−.7241,.2555] |
| 3413 | +.7717 [.0984,1.4449] |
| 原合并 | +.4235 [−.0618,.9087] |

逐seed区间是资源库中按原family方法进行的**回顾性重算**，不是原GitHub已发布的逐seed区间；原合并统计先经重建核验。应同时保留正seed、反向seed、原汇总和重算身份。

## 5. 外部MindMix：接入、诊断与完整性能不同

full融合资产已通过独立接入：对两个audio权重key作机械改名后，509/511个tensor按预期装载；未使用任务分类头不进入AAD路径。它与Stage1 EEG-only资产不一致的问题是两个事件。[E6]

| 已归档内容 | 结果与边界 |
| --- | --- |
| 官方评分接口 | 候选交换后仍偏特权target槽；batch1恒tie；盲双顺序边际修正后反对称、近似batch不变 |
| 16训练侧窗口 | attended ClipLoss .0087、ignored .0049、noise .0087；批内top-1均1；去CALRA后loss3.26、top-1 .0625 |
| 发布资产EEG敏感性 | 真实与噪声EEG盲边际r=.997，符号一致100% |
| 外部生产 | 当时8/10 complete，各50epoch；训练ClipLoss .003041–.003630 |
| 微调后审计 | 当时8/10 complete；公开记录未包含完整paired性能结论 |

这些观察支持指定资产与评分路径的审计。它们不能替代全fold的测试准确率，也不能预言所有充分训练CALRA都忽略EEG。正式比较保留完整系统与其EEG分支，以及各自的数据／标签访问身份。

## 6. 接包时优先核对的既有产物

| 对象 | 063bef5状态 | 接包时动作 |
| --- | --- | --- |
| ALN41 R2来源生产 | 8/8 complete | 核对权重、receipt并复用 |
| R2冻结提取 | 40/40，B0复用R1 | 复用兼容缓存 |
| R2儿童CE全FT | 29/30；3407齐，3413缺TCS outer4 | 先查是否已补齐；不能按旧缺项重复训练 |
| R2完整科学family、support、跨刺激 | 当时没有公开最终总表 | 查当前输出与任务状态，再判断缺什么 |
| MindMix完整路线A及审计 | 8/10＋8/10 | 查另外两fold及已有测试数组、全fold配对汇总 |
| MindMix当时缺fold | content_fold1/person_fold3、4 | 查询当前receipt，不从旧清单推仍在跑 |

可定位的单元清单为results/auditory_alignment_v3/unit_records/LANES_MANIFEST_036.tsv，之后若有新清单，以当前可验证产物为准。[E7]

跨刺激已完成语义核查与路线决定：MFF纯音33身份、bapa24身份、8个同日配对；共享standard/deviant关系，不是相同声音身份。该决定本身不是迁移成功或失败结果。[E8]

## 7. 可复用代码与真实边界

下表分清直接读过的旧实现与较新包登记的接口。Server需核对当前代码版本，不把旧函数名存在当作已完成新目标。

| 接口 | 可以复用 | 必须核验／补充 |
| --- | --- | --- |
| auditory_alignment_v2/foundation_adapter.py::Backbone | CB/REVE、full/PEFT/frozen等适配 | 严格load、实际可训练参数和更新账本 |
| auditory_alignment_v3/fm_aligned32.py::fit_aligned32 | 查询锚定、full_onestep_v1／warmup_then_all_v1 | 默认recipe是旧aln3，不可默用后称true-full |
| auditory_alignment_v3/aln34/cb_auditory.py::Stream / run_donor | source pool、checkpoint、合法wrong family映射 | Stream是跨family采样而非人内sampler；run_donor硬编码env/NCE |
| auditory_alignment_v3/prior33/views.py::open_with_rich / DonorBank | core/rich声音坐标、身份和时间访问 | 新人内采样、单窗范围、各队列描述子可用性 |
| auditory_alignment_v3/prior33/losses.py | NCE合法候选、传统CS、带宽标定 | NCE mask不能直接塞入CS Gram后仍称相同KDE对象 |
| auditory_alignment/losses_reference.py::cs_qmi | Gaussian CS与labels δ核 | δ核已经存在；新校准、null及完整统计量影响另接 |
| auditory_alignment_v3/aln34/content_time.py | 多描述子、训练侧残差、科学数组 | 旧conditional字段在新报告中说明为residual；不改旧身份 |
| auditory_alignment_v3/aln34/private_current_time_v2.py | 修正后的儿童校准与history分析 | 新checkpoint/schema适配 |
| auditory_alignment_v3/aln34/attention_transfer.py | 双候选顺序、20s窗口、mean/antisymmetric | 依赖候选评分须独立接入并保留原对照 |
| auditory_alignment_v3/aln34/science_aggregate_v2.py | 人级汇总、组分析 | 新endpoint/family与逐seed输出，不套旧硬编码范围 |

较新包登记的下列路径，需server当前代码核实：

- auditory_alignment_v3/aln35/support_contract.py、support_runtime.py：固定support/query及label access。
- auditory_alignment_v3/aln35/history_interface.py：history/twin与等校准。
- auditory_alignment_v3/aln35/science_export.py：多任务人级导出。
- auditory_alignment_v3/aln41/analysis.py：当前family统计。
- auditory_alignment_v3/paper/cs_atlas.py、cs_atlas_summary.py：共同依赖测量与汇总。
- MindMix生产入口按EXTERNAL_COMPARISON_BINDING.public.json定位；本文不猜测未核对的新模块名。

## 8. 数据与描述子的已知边界

**Source。** 固定rich视图为env/ss/sc，不等于所有目标队列均有同级rich。源EEG为64Hz带限缓存；重采样至200Hz不恢复高频。旧CBAUD单窗为q+[-26:38]共64点；新增细时间访问不能从它无损冒充导出。

**公共描述子。** 直接读到的旧content_time.features对DTU/FAU返回env、onset、5维spec、flux、Ac、Lz；对Federici仅返回env。谱、F0、语言在Federici不能被写成这条现成pipeline已经全覆盖。

**私有BDF。** 正式64儿童=55HA+9NH；20×200 epoch、250Hz、[-200,+600)ms。现成刺激code、history、block与人级metadata，不含连续声音waveform/声谱目标。code与物理频率映射未确证，不能自行赋予声学身份。

**事件审计。** 64儿童63,415目标epoch已从原注释至loader／support-query逐链核对，标签/history/信号/几何/QC/guard不一致均为0。child60确实使用不同序列，偏差率约.151、SOA约.849s、允许连续偏差；常规序列约.20、.781s。history异常来自真实协议不匹配，不能为此重做清洗或删儿童。[E9]

**推断单位。** 年龄、听力组、设备时长在人内为常量，关联分析在人级进行。Federici phantom不并入人群；HC-v不能冒称同儿童对照。空间与时间访问按真实接口标记。

## 9. 证据链接

所有链接固定到同一提交；完整路径清单另见evidence/server_required_paths.json。

- **[E1] R1报告**  
  https://github.com/W-Yinghao/auditory/blob/063bef5d0234c523043d6eef708f8defe2584d88/docs/auditory_alignment_v3/aln41/ROUND1_REPORT.md
- **[E2] R1 family全表**  
  https://github.com/W-Yinghao/auditory/blob/063bef5d0234c523043d6eef708f8defe2584d88/results/auditory_alignment_v3/aln41/r1/FAMILY_TABLES.md
- **[E3] R1原始对比**  
  https://github.com/W-Yinghao/auditory/blob/063bef5d0234c523043d6eef708f8defe2584d88/results/auditory_alignment_v3/aln41/r1/contrasts.json
- **[E4] 源学习诊断**  
  https://github.com/W-Yinghao/auditory/blob/063bef5d0234c523043d6eef708f8defe2584d88/docs/auditory_alignment_v3/aln42/SOURCE_LEARNING_REPORT.md
- **[E5] CS图谱**  
  https://github.com/W-Yinghao/auditory/blob/063bef5d0234c523043d6eef708f8defe2584d88/results/auditory_alignment_v3/paper/cs_atlas/ATLAS.md
- **[E6] MindMix接入与审计**  
  https://github.com/W-Yinghao/auditory/blob/063bef5d0234c523043d6eef708f8defe2584d88/docs/auditory_alignment_v3/aln42/ops/EXTERNAL_READINESS_REPORT.md
- **[E7] 逐单元清单**  
  https://github.com/W-Yinghao/auditory/blob/063bef5d0234c523043d6eef708f8defe2584d88/results/auditory_alignment_v3/unit_records/LANES_MANIFEST_036.tsv
- **[E8] 跨刺激决定**  
  https://github.com/W-Yinghao/auditory/blob/063bef5d0234c523043d6eef708f8defe2584d88/docs/auditory_alignment_v3/aln41/R2_CROSS_STIM_DECISION.md
- **[E9] 私有事件审计**  
  https://github.com/W-Yinghao/auditory/blob/063bef5d0234c523043d6eef708f8defe2584d88/docs/auditory_alignment_v3/aln42/EVENT_AUDIT_REPORT.md
- **[E10] 同access true-full三seed面板**  
  https://github.com/W-Yinghao/auditory/blob/063bef5d0234c523043d6eef708f8defe2584d88/docs/auditory_alignment_v3/ALN32_SEED_PANEL_RESULTS.md
- **[E11] 私有三seed面板与recipe对比**  
  https://github.com/W-Yinghao/auditory/blob/063bef5d0234c523043d6eef708f8defe2584d88/docs/auditory_alignment_v3/E_MULTI_SEED_RESULTS.md
- **[E12] 私有CB初始化×recipe因子控制**  
  https://github.com/W-Yinghao/auditory/blob/063bef5d0234c523043d6eef708f8defe2584d88/docs/auditory_alignment_v3/PRIVATE_CB_FACTORIAL_RESULTS.md

