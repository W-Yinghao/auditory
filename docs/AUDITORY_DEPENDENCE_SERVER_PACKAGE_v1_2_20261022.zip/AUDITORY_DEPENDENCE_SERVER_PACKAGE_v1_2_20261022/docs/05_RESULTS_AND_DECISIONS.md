# 05 回传格式、统计与科学讨论

## 1. 最终文件

回传一个带实际production commit的结果目录，至少有：

- ROUND_REPORT.md：按可测、可比、可迁移、测量驱动使用四问写结论，明确训练与测量的不同归因。
- SOURCE_UPDATE.md：本次接包的最新HEAD、结果变化、旧缺项现在怎样、哪些任务复用／新增。
- EXTERNAL_COMPARISON.md：MindMix完整系统、EEG分支、线性参照、有效local／CB／REVE；官方与统一协议及数据访问列明。
- E0_SELECTION.json：四短训轨迹、独立source-dev分数、固定模式选择。
- per_person.jsonl：所有人级端点，保留全部seed／support抽样。
- contrasts.json及contrasts.md：逐seed、三seed平均、区间／family身份。
- predictions/：所有候选和selector在共同query的可复算概率／注意分数；只输出授权去标识字段。
- measurement/：raw／null draws／excess／z状态、A/B/C、核和样本量诊断、校准及anchor身份。
- selection/：每个support的候选分数、决策、fallback、query指纹。
- run_receipts/：实际代码、数据和权重hash、参数、时间／显存／GPUh、完成与错误状态。
- LIMITATIONS.md：不能执行的明确路径、已观察开发历史、推断范围；不把限制堆成论文的主体。

不输出原始EEG或身份映射。去标识个体结果已获用户授权，无需再次询问。

## 2. 每行端点的最低字段

schema_version, experiment_id, arm, backbone, training_mode, train_seed,
cohort, participant_id, outer_fold, support_seed, support_budget,
task, descriptor, feature_layer, window_support_ms, endpoint, value,
n_trials, n_anchors, access_level, checkpoint_sha256, split_sha256,
query_sha256, calibration_sha256, code_commit, status, missing_reason。

测量再加raw_cs、null_mean、null_sd、excess_cs、z、z_status、null_design_id、
actual_null_draws、sigma_u、sigma_y、kernel_diagnostics、panel_id。
不能用0补缺失，不因z无定义丢弃raw／excess。

历史复用结果保留original_protocol、original_commit、retrospective_reanalysis字段；不能改名成这轮新跑的确认结果。

## 3. 主统计与预定比较

人的预测／测量向量是推断单位。窗口、事件、support抽样、fold和训练seed不当作额外听者。

每个私有儿童先平均五个U10支持抽样；每个训练seed独立保存完整人级结果。主合并再对三个训练seed取每人的平均，计算配对效应和人级cluster bootstrap区间。这个区间条件于已运行的三个seed，不声称精确估计任意未来训练seed的分布；另报告逐seed效应、区间及方向一致性。

同一人的所有臂／指标在同一次bootstrap保留配对。队列间分别抽听者；不同队列不能把同名匿名ID当同一人。人群小组以实际n报告，不因窗口多声称高精度。固定bootstrap RNG、10,000重采样；复用当前经过校验的max-|t| simultaneous interval实现，保留其算法、失败replicate处理和无方差端点状态。

| Family | 预定主要比较 |
| --- | --- |
| F_MEASURE | DTU／FAU env、spec、Lz中CS-pair−B0/NCE/Sigmoid的同属性excess差；缺失属性标missing，不以事后挑选替换 |
| F_ATTENTION | DTU／FAU 20s：CS-pair−B0/NCE/Sigmoid的准确率差 |
| F_PRIVATE | 固定共同query、无个人更新U0：CS-pair−B0/NCE/Sigmoid的history之外log-score gain差 |
| F_SELECTION | U10：依赖选择−固定选择／普通CV选择／均匀组合的query log-score改进 |
| F_EXTERNAL | 同一共同query上CS-pair与实际完整MindMix路线、其EEG分支和预定传统读出；协议／访问不一致单列，不合称loss效应 |

同一family内计算同时95%区间，个别未校正区间可补充但标明身份。F_MEASURE跨n／带宽的小面板是敏感性描述，不用选取最好格子替换主参数。private δ-measure另单列为描述与selector输入，不能当F_PRIVATE的同义终点。

raw-CS和WRONG仅seed3401，单列机制对照；不能与主三seed模型混成同精度排行榜。B0虽在三个seed配对中复用，原始checkpoint及测量只算一次，不制造“B0三次独立训练”。

完整外部结果优先使用同query预测重算；若无法完全配对，给出全样本与交集样本两表及差异原因。不得用训练ClipLoss代替测试性能。

## 4. 逐seed正结果不能被平均掩埋

每条关键比较并排给出：

1. 每个seed的点估计、区间、实际人数；
2. 完整seed向量与合并效应；
3. 对应共同query及是否为回顾性分析；
4. 失败／缺失／未运行，不补零。

区分“正点估计”“单seed区间阳性”“合并区间阳性”“族内同时区间阳性”。平均未分辨不擦掉两个seed的阳性；最好seed也不能证明方法稳定。

对旧FAU env/W1的TCS−B0等既有单seed阳性，保留原结果与审计重算身份，不因为本轮改了方法名而丢弃。

## 5. 图表只服务四问

建议六张核心图／表，不预写效应方向：

1. 同一训练过程的true、null、excess与backbone／projector轨迹。
2. 同属性共同测量的配对方法差及逐seed散点。
3. 内容读出与注意判定并列，展示二者可分离的实际证据。
4. 私有当前事件的history-only、history+EEG及strict-twin风险差。
5. U10依赖选择与三种策略的query效用、选择分布与fallback。
6. 外部MindMix完整系统／EEG分支及访问身份的共同query表。

已有时间三窗、年龄、HA／CI／设备结果作为有问题指向的补充。时间位置、输入支持或信息利用是否解释某个差异，应由相应结果决定；不为了形成故事强制统一方向。

## 6. 回答时必须作出的判断

ROUND_REPORT最后写四个有证据的判断：

- **学习：** CS-pair相对B0和目标对照改变了什么？是否只改变被优化的分数？
- **测量：** 同属性方法差对样本量、带宽与核退化是否敏感？哪些能稳定报告？
- **用途：** 注意、当前事件／history之外、跨刺激中哪些支持转移？哪个具体范围尚无支持？
- **使用：** 依赖选择是否改善独立query，是否超过同支持的普通读出选择？属于CS测量还是CS训练的收益？

再提出“最多一个最值得下一轮确认的未决问题”和能改变判断的最少证据。不要自动生成新全矩阵；不要以投稿需要替代科学判断。若希望把centering本身升为主要方法贡献，下一轮应补raw-CS的对应seed，而非先写成稳定改进。

