#!/usr/bin/env python3
"""Read-only project intake, logical plan and structural binding validation.

No training, Slurm submission, cancellation, deletion or publishing.
Only --fetch updates remote git references; it never merges or checks out.
The plan consists of logical responsibilities, not fabricated production CLIs.
"""
from __future__ import annotations

import argparse
import datetime as dt
import getpass
import hashlib
import json
from pathlib import Path
import re
import shutil
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]


def now():
    return dt.datetime.now(dt.timezone.utc).isoformat()


def load(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def save(path, value):
    p = Path(path).expanduser().resolve()
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    return str(p)


def command(argv, cwd=None, timeout=45):
    try:
        p = subprocess.run(argv, cwd=cwd, capture_output=True, text=True, timeout=timeout)
        # Avoid logging a credential-bearing URL from a remote's error message.
        redact = lambda s: re.sub(r"(https?://)[^/\s@]+@", r"\1<redacted>@", s[:12000])
        return {"returncode": p.returncode, "stdout": redact(p.stdout),
                "stderr": redact(p.stderr)}
    except (OSError, subprocess.TimeoutExpired) as exc:
        return {"returncode": None, "error": type(exc).__name__}


def sha(path):
    h = hashlib.sha256()
    with Path(path).open("rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def intake(args):
    repo = Path(args.repo).expanduser().resolve()
    if not repo.is_dir():
        raise ValueError("Repo directory does not exist")
    report = {"schema_version": "1.2", "checked_at_utc": now(),
              "repo": str(repo), "read_only_except_optional_fetch": True,
              "baseline_is_not_live_status": True}
    if args.fetch:
        report["fetch"] = command(["git", "fetch", "origin"], cwd=repo)
    else:
        report["fetch"] = {"status": "not_requested",
                           "note": "Live remote status still requires server verification"}
    report["git"] = {}
    for key, cmd in {
        "head": ["rev-parse", "HEAD"],
        "branch": ["branch", "--show-current"],
        "status": ["status", "--porcelain=v1"],
        "origin_default": ["symbolic-ref", "refs/remotes/origin/HEAD"],
        "origin_head": ["rev-parse", "refs/remotes/origin/HEAD"],
        "recent": ["log", "-5", "--format=%H %cI %s"],
    }.items():
        report["git"][key] = command(["git"] + cmd, cwd=repo)
    spec = load(ROOT / "evidence/server_required_paths.json")
    report["baseline_results_commit"] = spec["baseline_results_commit"]
    report["latest_unknown_items"] = spec["latest_unknown_items"]
    report["known_files"] = []
    for entry in spec["files"]:
        relative = Path(entry["path"])
        if relative.is_absolute() or ".." in relative.parts:
            raise ValueError("Unsafe path in evidence index")
        path = repo / relative
        record = {"path": entry["path"], "role": entry["role"],
                  "baseline_status": entry["baseline_status"],
                  "exists": path.is_file()}
        if path.is_file():
            size = path.stat().st_size
            record["size_bytes"] = size
            if size <= 8 * 1024 * 1024:
                record["sha256"] = sha(path)
            else:
                record["hash_status"] = "not_read_large_file_in_metadata_intake"
        report["known_files"].append(record)
    if args.queue:
        if shutil.which("squeue"):
            report["owned_queue"] = command(
                ["squeue", "-h", "-u", getpass.getuser(),
                 "-o", "%i|%j|%T|%b|%R"])
            report["queue_note"] = (
                "Raw owned-job inventory; inspect project identity and GPU resource "
                "counts manually. No job mutations, no claimed 10-GPU certification.")
        else:
            report["owned_queue"] = {"status": "squeue_unavailable"}
    report["does_not_prove"] = [
        "current experiment completion", "data/null exchangeability",
        "absence of pending duplicate jobs", "latest remote code integration"
    ]
    output = save(args.out, report)
    print(json.dumps({"status": "written", "output": output,
                      "known_files_checked": len(report["known_files"]),
                      "fresh_fetch_succeeded": report["fetch"].get("returncode") == 0}))


def binding_errors(binding, stage):
    errors = []
    require = lambda test, message: errors.append(message) if not test else None
    require(binding.get("schema_version") == "1.2", "schema_version must be 1.2")
    require(binding.get("repository") == "W-Yinghao/auditory", "repository identity")
    for field in ("current_commit", "remote_commit"):
        require(bool(re.fullmatch(r"[0-9a-f]{40}", str(binding.get(field) or ""))),
                field + " must be an observed full git SHA")
    require(binding.get("live_remote_verified") is True, "live_remote_verified")
    require(binding.get("prior_results_reconciled") is True, "prior_results_reconciled")
    for field in ("checked_at_utc", "isolated_worktree", "source_update_report"):
        require(bool(binding.get(field)), field + " is required")
    if stage in ("source", "evaluation"):
        require(bool(re.fullmatch(r"[0-9a-f]{40}",
                                 str(binding.get("code", {}).get("production_commit") or ""))),
                "code.production_commit must be observed")
        required_assets = ["source_init", "source_manifest", "rich_manifest",
                           "audio_heads", "source_calibration", "source_dev_panel"]
        checks = ["numpy_reference_passed", "torch_reference_passed",
                  "source_real_batch_passed", "source_access_and_schedule_passed",
                  "full_and_lora_parameter_audit_passed", "save_resume_passed"]
        code_keys = ["sampler", "trainer", "feature_exporter"]
        require(binding.get("anchors_per_person") in (32, 64),
                "anchors_per_person must be selected by coverage before dev effects")
        if stage == "evaluation":
            required_assets += ["private_split", "private_support_manifest",
                                "measurement_panels", "null_design", "external_binding"]
            checks += ["measurement_and_null_reviewed", "private_support_budget_reviewed",
                       "query_access_and_candidate_symmetry_passed"]
            code_keys += ["measurement_adapter", "public_scorer",
                          "private_adapter", "aggregation"]
            require(binding.get("selected_mode") in ("full", "lora"),
                    "selected_mode must be set by E0")
        for key in required_assets:
            item = binding.get("assets", {}).get(key, {})
            require(isinstance(item.get("path"), str) and bool(item.get("path")),
                    "assets." + key + ".path")
            require(bool(re.fullmatch(r"[0-9a-f]{64}", str(item.get("sha256") or ""))),
                    "assets." + key + ".sha256")
        for key in checks:
            require(binding.get("checks", {}).get(key) is True, "checks." + key)
        for key in code_keys:
            require(bool(binding.get("code", {}).get(key)), "code." + key)
    return errors


def validate(args):
    errors = binding_errors(load(args.binding), args.stage)
    print(json.dumps({"status": "invalid" if errors else "structurally_valid",
                      "stage": args.stage, "errors": errors,
                      "scope": "structural_only; paths, receipts and scientific validity need actual audit"},
                     ensure_ascii=False, indent=2))
    return 2 if errors else 0


def make_plan(config, selected_mode=None):
    tasks = []
    def add(task_id, kind, needs=(), **extra):
        tasks.append(dict(task_id=task_id, kind=kind, depends_on=list(needs),
                          status="planned", **extra))
    add("intake", "current_repo_and_jobs")
    add("reconcile_prior", "reuse_results_and_checkpoints", ["intake"])
    add("reference_and_integration", "slurm_math_real_batch_and_wrapper", ["intake"])
    add("external_report", "finish_existing_paired_external_report", ["reconcile_prior"])
    e0_ids = []
    for arm in config["e0"]["arms"]:
        for mode in config["e0"]["modes"]:
            task_id = "e0." + arm + "." + mode
            e0_ids.append(task_id)
            add(task_id, "source_pilot", ["reference_and_integration"],
                arm=arm, mode=mode, seed=config["e0"]["seed"],
                start_step=0, end_step=config["e0"]["updates"],
                schedule_total_steps=config["source"]["full_steps"])
    add("select_mode", "independent_source_dev_rule", e0_ids)
    models = []
    mode_label = selected_mode or "SELECTED_BY_E0"
    for arm in config["primary_arms"]:
        for seed in config["train_seeds"]:
            task_id = "source." + arm + "." + str(seed)
            models.append(task_id)
            resume = arm in config["e0"]["arms"] and seed == config["e0"]["seed"]
            add(task_id, "source_production", ["select_mode"], arm=arm,
                mode=mode_label, seed=seed,
                start_step=config["e0"]["updates"] if resume else 0,
                end_step=config["source"]["full_steps"],
                resume_from=("e0." + arm + "." + mode_label) if resume else None)
    for arm in config["diagnostic_arms"]:
        task_id = "source." + arm + "." + str(config["diagnostic_seed"])
        models.append(task_id)
        add(task_id, "source_mechanism_control", ["select_mode"], arm=arm,
            mode=mode_label, seed=config["diagnostic_seed"],
            start_step=0, end_step=config["source"]["full_steps"])
    add("export_frozen", "current_and_legacy_independent_EEG_features",
        models + ["reconcile_prior"], include_same_initial_B0=True)
    add("common_measure", "shared_profiles_and_small_sensitivity",
        ["export_frozen"])
    add("public_attention", "strict_20s_candidate_symmetric_use",
        ["export_frozen"])
    add("private_U0", "current_event_and_history_gain", ["export_frozen"])
    add("private_U10_selection", "support_only_four_policy_query_test",
        ["private_U0", "common_measure"])
    add("legacy_time_axis", "reuse_existing_time_profiles",
        ["reconcile_prior"], optional=False)
    add("public_support_selection", "optional_ss_support_to_attention",
        ["public_attention", "common_measure"], optional=True)
    add("new_time_perturbation", "optional_three_native_crops",
        ["export_frozen"], optional=True)
    add("round_report", "all_seed_scientific_decision",
        ["common_measure", "public_attention", "private_U10_selection",
         "external_report", "legacy_time_axis"])
    ids = {t["task_id"] for t in tasks}
    if len(ids) != len(tasks):
        raise ValueError("Duplicate task IDs")
    for t in tasks:
        if set(t["depends_on"]) - ids:
            raise ValueError("Unknown dependency")
    # All tasks are emitted in topological order.
    seen = set()
    for t in tasks:
        if not set(t["depends_on"]) <= seen:
            raise ValueError("Non-topological plan")
        seen.add(t["task_id"])
    total = sum(t.get("end_step", 0) - t.get("start_step", 0)
                for t in tasks if t["kind"].startswith("source_"))
    if total != config["budget"]["max_source_updates"]:
        raise ValueError("Update budget mismatch")
    return {"schema_version": "1.2", "kind": "logical_plan_not_job_submission",
            "generated_at_utc": now(), "selected_mode": selected_mode,
            "planned_source_updates": total,
            "production_models": len(models),
            "scientific_effect_gates": False,
            "production_integration_required": True, "tasks": tasks}


def plan(args):
    config = load(args.config or ROOT / "configs/round.json")
    binding = load(args.binding) if args.binding else {}
    mode = binding.get("selected_mode")
    if mode not in (None, "full", "lora"):
        raise ValueError("Invalid selected_mode")
    value = make_plan(config, mode)
    output = save(args.out, value)
    print(json.dumps({"status": "written", "output": output,
                      "logical_units": len(value["tasks"]),
                      "planned_source_updates": value["planned_source_updates"],
                      "launchable": False,
                      "reason": "logical plan; bind current production wrappers on server"}))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    p = sub.add_parser("intake")
    p.add_argument("--repo", required=True)
    p.add_argument("--out", required=True)
    p.add_argument("--fetch", action="store_true")
    p.add_argument("--queue", action="store_true")
    p = sub.add_parser("validate")
    p.add_argument("--binding", required=True)
    p.add_argument("--stage", choices=["intake", "source", "evaluation"], default="intake")
    p = sub.add_parser("plan")
    p.add_argument("--binding")
    p.add_argument("--config")
    p.add_argument("--out", required=True)
    args = parser.parse_args()
    try:
        if args.command == "intake":
            intake(args)
        elif args.command == "plan":
            plan(args)
        else:
            return validate(args)
    except (ValueError, KeyError, OSError, json.JSONDecodeError) as exc:
        print(json.dumps({"status": "error", "error": str(exc)}, ensure_ascii=False))
        return 2
    return 0


if __name__ == "__main__":
    sys.exit(main())

